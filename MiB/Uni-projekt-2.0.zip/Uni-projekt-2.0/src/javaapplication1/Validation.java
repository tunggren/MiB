package javaapplication1;

import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class Validation {

    public static boolean textFieldHasValue(JTextField rutaAttKolla) {
        boolean resultat = true;

        if (rutaAttKolla.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Användarnamn eller lösenord är tomt.");
            resultat = false;
            rutaAttKolla.requestFocus();
        }

        return resultat;
    }

    public static boolean passwordLengthOk(String password){
        boolean length = true;
        
        if(password.length() >= 7){
            length = false;
        }
        return length;
    }
    
    public static boolean isNumber(String maybeNumber) {
        
        if(maybeNumber.matches("[0-9-]+")){
            return true;        
        }else{
            return false;
        } 
    }
    
}
