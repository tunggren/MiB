package javaapplication1;

import java.awt.Color;
import java.awt.Component;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.Border;
import oru.inf.InfDB;
import oru.inf.InfException;
import java.util.HashMap;

public class Dashboard_admin extends javax.swing.JFrame {

    // default border for the menu items
    Border default_border = BorderFactory.createMatteBorder(1, 0, 1, 0, new Color(46, 49, 49));

    // yellow border for the menu items
    Border yellow_border = BorderFactory.createMatteBorder(1, 0, 1, 0, Color.YELLOW);

    // create an array of jlabels
    JLabel[] menuLabels = new JLabel[6];

    // create an array of jpanels
    JPanel[] panels = new JPanel[6];
    private String ID;
    private String namn;
    private InfDB idb;

    public Dashboard_admin(InfDB idb, String namn, String ID) {
        initComponents();
        this.idb = idb;
        this.ID = ID;

        // centrerar programmet
        this.setLocationRelativeTo(null);
        //Skapar systemAdmin
        
        fyllComboBoxPlats();
        fyllComboBoxOmrade();
        fyllComboBoxValjAlien();
        fyllComboBoxAgent();
        fyllComboBoxUtrustning();
        fyllComboBoxKontor();
        //övrepanelen "welcome"
        jLbl_welcome.setText("Välkommen " + namn + " till MIBs admin applikation");

        // panel logo border
        Border panelBorder = BorderFactory.createMatteBorder(0, 0, 2, 0, Color.lightGray);
        jPanel_logoANDname.setBorder(panelBorder);
        // panel container border
        Border containerBorder = BorderFactory.createMatteBorder(1, 1, 1, 1, new Color(46, 49, 49));
        jPanel_container.setBorder(containerBorder);

        // Makes current Agent / alien name appear
        jLabelAgentNamn.setText(namn);

        // populate the menuLabels array
        // you can use a for loop to do that
        menuLabels[0] = jLabel_menuItem1;
        menuLabels[1] = jLabel_menuItem2;
        menuLabels[2] = jLabel_menuItem3;
        menuLabels[3] = jLabel_menuItem4;
        menuLabels[4] = jLabel_menuItem5;
        menuLabels[5] = jLabel_menuItem6;

        // populate the panels array
        panels[0] = jPanel_dashboard;
        panels[1] = jPanel_users;
        panels[2] = jPanel_Utrustning;
        panels[3] = jPanel_lista;
        panels[4] = jPanel_AdminMeny;
        panels[5] = jPanel_Agent;

        addActionToMenuLabels();

    }

    // create a function to set the label background color
    public void setLabelBackround(JLabel label) {
        // reset labels to their default design
        for (JLabel menuItem : menuLabels) {
            // change the jlabel background color to white
            menuItem.setBackground(new Color(46, 49, 49));
            // change the jlabel Foreground color to blue
            menuItem.setForeground(Color.white);
        }

        // change the jlabel background color to white
        label.setBackground(Color.white);
        // change the jlabel Foreground color to blue
        label.setForeground(Color.blue);
    }

    // create a function to show the selected panel
    public void showPanel(JPanel panel) {
        // hide panels
        for (JPanel pnl : panels) {
            pnl.setVisible(false);
        }

        // and show only this panel
        panel.setVisible(true);
    }

    public void addActionToMenuLabels() {
        // get labels in the jpanel menu
        Component[] components = jPanel_menu.getComponents();
        showPanel(jPanel_dashboard);
        for (Component component : components) {
            if (component instanceof JLabel) {
                JLabel label = (JLabel) component;

                label.addMouseListener(new MouseListener() {
                    @Override
                    public void mouseClicked(MouseEvent e) {

                        // change the jlabel background and Foreground
                        setLabelBackround(label);

                        // displa the selected panel
                        switch (label.getText().trim()) {
                            case "Dashboard":
                                showPanel(jPanel_dashboard);
                                break;

                            case "Användare":
                                showPanel(jPanel_users);
                                break;

                            case "Utrustning":
                                showPanel(jPanel_Utrustning);
                                break;

                            case "Sök/Lista":
                                showPanel(jPanel_lista);
                                break;

                            case "Admin meny":
                                showPanel(jPanel_AdminMeny);
                                break;

                            case "Agent":
                                showPanel(jPanel_Agent);
                                break;

                        }

                    }

                    @Override
                    public void mousePressed(MouseEvent e) {
                    }

                    @Override
                    public void mouseReleased(MouseEvent e) {
                    }

                    @Override
                    public void mouseEntered(MouseEvent e) {

                        // set the border to yellow
                        label.setBorder(yellow_border);

                    }

                    @Override
                    public void mouseExited(MouseEvent e) {

                        // reset to the default border
                        label.setBorder(default_border);

                    }
                });

            }
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMenuBar2 = new javax.swing.JMenuBar();
        jMenu3 = new javax.swing.JMenu();
        jMenu4 = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jPanel_container = new javax.swing.JPanel();
        jPanel_menu = new javax.swing.JPanel();
        jPanel_logoANDname = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jLabelAgentNamn = new javax.swing.JLabel();
        jLabel_menuItem1 = new javax.swing.JLabel();
        jLabel_menuItem2 = new javax.swing.JLabel();
        jLabel_menuItem3 = new javax.swing.JLabel();
        jLabel_menuItem4 = new javax.swing.JLabel();
        jLabel_menuItem5 = new javax.swing.JLabel();
        jLabel_menuItem6 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLbl_welcome = new javax.swing.JLabel();
        jPanel_dashboard = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        jCombo_Omrade2 = new javax.swing.JComboBox<>();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTxt_TOP3 = new javax.swing.JTextArea();
        jButton1 = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jTxtNewPassword = new javax.swing.JTextField();
        jBtnPasswordChange = new javax.swing.JButton();
        jLblDisplayPassword = new javax.swing.JLabel();
        jPanel_Utrustning = new javax.swing.JPanel();
        jPanel18 = new javax.swing.JPanel();
        jLabel38 = new javax.swing.JLabel();
        jLbl_BenamningUtrustning1 = new javax.swing.JLabel();
        jBtn_RegistreraUtrustning1 = new javax.swing.JButton();
        jCombo_Utrustning1 = new javax.swing.JComboBox<>();
        jLabel5 = new javax.swing.JLabel();
        jPanel19 = new javax.swing.JPanel();
        jLabel43 = new javax.swing.JLabel();
        jLbl_BenamningUtrustning2 = new javax.swing.JLabel();
        jBtn_RegistreraUtrustning2 = new javax.swing.JButton();
        jTxt_benamning = new javax.swing.JTextField();
        jCombo_UtrustningTyp = new javax.swing.JComboBox<>(new String[] { "Teknik", "vapen", "kommunikation" });
        jLbl_BenamningUtrustning3 = new javax.swing.JLabel();
        jLbl_typFraga = new javax.swing.JLabel();
        jTxtTypFragaSvar = new javax.swing.JTextField();
        jLabel18 = new javax.swing.JLabel();
        jPanel_users = new javax.swing.JPanel();
        jPanel11 = new javax.swing.JPanel();
        jLabel19 = new javax.swing.JLabel();
        jLbl_MsgReg1 = new javax.swing.JLabel();
        jCombo_ValjAlien2 = new javax.swing.JComboBox<>();
        jBtn_BekraftaSok = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jCheckBox1 = new javax.swing.JCheckBox();
        jTxt_NyttDatum = new javax.swing.JTextField();
        jCheckBox2 = new javax.swing.JCheckBox();
        jCheckBox3 = new javax.swing.JCheckBox();
        jCheckBox4 = new javax.swing.JCheckBox();
        jCheckBox5 = new javax.swing.JCheckBox();
        jCheckBox6 = new javax.swing.JCheckBox();
        jCheckBox7 = new javax.swing.JCheckBox();
        jTxt_NyttLosenord = new javax.swing.JTextField();
        jTxt_NyttNamn = new javax.swing.JTextField();
        jTxt_NyttNr = new javax.swing.JTextField();
        jCombo_Plats2 = new javax.swing.JComboBox<>();
        jCombo_AnsvarigAgent2 = new javax.swing.JComboBox<>();
        jCombo_Ras2 = new javax.swing.JComboBox<>(new String[] { "BOGLODITE", "WORM", "SQUID" });
        jLabel7 = new javax.swing.JLabel();
        jTxt_RasFraga2 = new javax.swing.JTextField();
        jPanel12 = new javax.swing.JPanel();
        jLabel20 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jTxt_Losenord = new javax.swing.JTextField();
        jTxt_Namn = new javax.swing.JTextField();
        jTxt_Telefon = new javax.swing.JTextField();
        jBtn_Registrera1 = new javax.swing.JButton();
        jTxt_Datum = new javax.swing.JTextField();
        jLbl_MsgReg2 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jCombo_Plats1 = new javax.swing.JComboBox<>();
        jCombo_Ras1 = new javax.swing.JComboBox<>(new String[] { "BOGLODITE", "WORM", "SQUID" });
        jCombo_AnsvarigAgent1 = new javax.swing.JComboBox<>();
        jLabel6 = new javax.swing.JLabel();
        jTxt_Rasfraga = new javax.swing.JTextField();
        jLbl_RegConfirm = new javax.swing.JLabel();
        jLabel44 = new javax.swing.JLabel();
        jPanel_lista = new javax.swing.JPanel();
        jPanel14 = new javax.swing.JPanel();
        jLabel39 = new javax.swing.JLabel();
        jLabel40 = new javax.swing.JLabel();
        jLabel42 = new javax.swing.JLabel();
        jLbl_ListaMellanDatum = new javax.swing.JLabel();
        jBtn_Registrera4 = new javax.swing.JButton();
        jLbl_MsgReg4 = new javax.swing.JLabel();
        jBtn_listaBoglodite = new javax.swing.JButton();
        jBtn_Registrera8 = new javax.swing.JButton();
        jCombo_Plats = new javax.swing.JComboBox<>();
        jBtn_listaSquid = new javax.swing.JButton();
        jBtn_listaWorm = new javax.swing.JButton();
        jTxt_listaDatum1 = new javax.swing.JTextField();
        jTxt_listaDatum2 = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel41 = new javax.swing.JLabel();
        jLbl_ListaMellanDatum1 = new javax.swing.JLabel();
        jCombo_Omrade1 = new javax.swing.JComboBox<>();
        jBtn_Registrera5 = new javax.swing.JButton();
        jCombo_ValjAlien = new javax.swing.JComboBox<>();
        jBtn_BekraftaSok1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jBtn_Utrustningen = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTxt_listaSvarRuta = new javax.swing.JTextArea();
        jPanel_AdminMeny = new javax.swing.JPanel();
        jPanel8 = new javax.swing.JPanel();
        jLabel34 = new javax.swing.JLabel();
        jNamnPaAgent = new javax.swing.JTextField();
        jCombo_Omrade5 = new javax.swing.JComboBox<>();
        jAndraOmradesChef = new javax.swing.JButton();
        jPanel9 = new javax.swing.JPanel();
        jLabel35 = new javax.swing.JLabel();
        jCombo_ValjAlien3 = new javax.swing.JComboBox<>();
        jButton5 = new javax.swing.JButton();
        jPanel16 = new javax.swing.JPanel();
        jLabel36 = new javax.swing.JLabel();
        jNamnPaAgent2 = new javax.swing.JTextField();
        jCombo_Kontor = new javax.swing.JComboBox<>();
        jButton3 = new javax.swing.JButton();
        jPanel17 = new javax.swing.JPanel();
        jLabel37 = new javax.swing.JLabel();
        jCombo_ValjAgent2 = new javax.swing.JComboBox<>();
        jButton4 = new javax.swing.JButton();
        jPanel_Agent = new javax.swing.JPanel();
        jPanel13 = new javax.swing.JPanel();
        jLabel27 = new javax.swing.JLabel();
        jLbl_MsgReg3 = new javax.swing.JLabel();
        jCombo_ValjAgent = new javax.swing.JComboBox<>();
        jBtn_BekraftaSok2 = new javax.swing.JButton();
        jLabel14 = new javax.swing.JLabel();
        jCheckBox8 = new javax.swing.JCheckBox();
        jTxt_NyttDatum1 = new javax.swing.JTextField();
        jCheckBox9 = new javax.swing.JCheckBox();
        jCheckBox10 = new javax.swing.JCheckBox();
        jCheckBox11 = new javax.swing.JCheckBox();
        jCheckBox12 = new javax.swing.JCheckBox();
        jCheckBox13 = new javax.swing.JCheckBox();
        jTxt_NyttLosenord1 = new javax.swing.JTextField();
        jTxt_NyttNamn1 = new javax.swing.JTextField();
        jTxt_NyttNr1 = new javax.swing.JTextField();
        jCombo_Omrade4 = new javax.swing.JComboBox<>();
        jCombo_AdminStatus1 = new javax.swing.JComboBox<>(new String[] { "J", "N" });
        jLabel16 = new javax.swing.JLabel();
        jPanel15 = new javax.swing.JPanel();
        jLabel28 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        jLabel33 = new javax.swing.JLabel();
        jTxt_Losenord1 = new javax.swing.JTextField();
        jTxt_Namn1 = new javax.swing.JTextField();
        jTxt_Telefon1 = new javax.swing.JTextField();
        jBtn_Registrera2 = new javax.swing.JButton();
        jTxt_Datum1 = new javax.swing.JTextField();
        jLbl_MsgReg5 = new javax.swing.JLabel();
        jCombo_Omrade3 = new javax.swing.JComboBox<>();
        jCombo_AdminStatus = new javax.swing.JComboBox<>(new String[] { "J", "N" });
        jLbl_RegConfirm1 = new javax.swing.JLabel();

        jMenu3.setText("File");
        jMenuBar2.add(jMenu3);

        jMenu4.setText("Edit");
        jMenuBar2.add(jMenu4);

        jMenuItem1.setText("jMenuItem1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        jPanel_container.setBackground(new java.awt.Color(255, 255, 0));

        jPanel_menu.setBackground(new java.awt.Color(46, 49, 49));

        jPanel_logoANDname.setBackground(new java.awt.Color(46, 49, 49));

        jLabel8.setFont(new java.awt.Font("Verdana", 1, 24)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 0));
        jLabel8.setText("MenInBlack");

        jLabelAgentNamn.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabelAgentNamn.setForeground(new java.awt.Color(255, 255, 0));

        javax.swing.GroupLayout jPanel_logoANDnameLayout = new javax.swing.GroupLayout(jPanel_logoANDname);
        jPanel_logoANDname.setLayout(jPanel_logoANDnameLayout);
        jPanel_logoANDnameLayout.setHorizontalGroup(
            jPanel_logoANDnameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel_logoANDnameLayout.createSequentialGroup()
                .addGroup(jPanel_logoANDnameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel_logoANDnameLayout.createSequentialGroup()
                        .addGap(35, 35, 35)
                        .addComponent(jLabelAgentNamn, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel_logoANDnameLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel8)))
                .addContainerGap(20, Short.MAX_VALUE))
        );
        jPanel_logoANDnameLayout.setVerticalGroup(
            jPanel_logoANDnameLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel_logoANDnameLayout.createSequentialGroup()
                .addGap(13, 13, 13)
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabelAgentNamn, javax.swing.GroupLayout.DEFAULT_SIZE, 25, Short.MAX_VALUE))
        );

        jLabel_menuItem1.setBackground(new java.awt.Color(46, 49, 49));
        jLabel_menuItem1.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jLabel_menuItem1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel_menuItem1.setText("  Dashboard");
        jLabel_menuItem1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel_menuItem1.setOpaque(true);

        jLabel_menuItem2.setBackground(new java.awt.Color(46, 49, 49));
        jLabel_menuItem2.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jLabel_menuItem2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel_menuItem2.setText("Användare");
        jLabel_menuItem2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel_menuItem2.setOpaque(true);

        jLabel_menuItem3.setBackground(new java.awt.Color(46, 49, 49));
        jLabel_menuItem3.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jLabel_menuItem3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel_menuItem3.setText("Utrustning");
        jLabel_menuItem3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel_menuItem3.setOpaque(true);

        jLabel_menuItem4.setBackground(new java.awt.Color(46, 49, 49));
        jLabel_menuItem4.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jLabel_menuItem4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel_menuItem4.setText("  Sök/Lista");
        jLabel_menuItem4.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel_menuItem4.setOpaque(true);

        jLabel_menuItem5.setBackground(new java.awt.Color(46, 49, 49));
        jLabel_menuItem5.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jLabel_menuItem5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel_menuItem5.setText("Agent");
        jLabel_menuItem5.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel_menuItem5.setOpaque(true);

        jLabel_menuItem6.setBackground(new java.awt.Color(46, 49, 49));
        jLabel_menuItem6.setFont(new java.awt.Font("SansSerif", 0, 14)); // NOI18N
        jLabel_menuItem6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel_menuItem6.setText("Admin meny");
        jLabel_menuItem6.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel_menuItem6.setOpaque(true);

        javax.swing.GroupLayout jPanel_menuLayout = new javax.swing.GroupLayout(jPanel_menu);
        jPanel_menu.setLayout(jPanel_menuLayout);
        jPanel_menuLayout.setHorizontalGroup(
            jPanel_menuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel_menuLayout.createSequentialGroup()
                .addGap(38, 38, 38)
                .addComponent(jPanel_logoANDname, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(jLabel_menuItem1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jLabel_menuItem4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel_menuLayout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addComponent(jLabel_menuItem3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel_menuLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel_menuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel_menuItem6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel_menuItem5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel_menuItem2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel_menuLayout.setVerticalGroup(
            jPanel_menuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel_menuLayout.createSequentialGroup()
                .addComponent(jPanel_logoANDname, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(43, 43, 43)
                .addComponent(jLabel_menuItem1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel_menuItem2, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel_menuItem3, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel_menuItem4, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel_menuItem6, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel_menuItem5, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        jPanel2.setBackground(new java.awt.Color(46, 49, 49));

        jLbl_welcome.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLbl_welcome.setForeground(new java.awt.Color(255, 255, 0));
        jLbl_welcome.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLbl_welcome.setText("Welcome Agent to MIB's admin application");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jLbl_welcome, javax.swing.GroupLayout.PREFERRED_SIZE, 881, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLbl_welcome, javax.swing.GroupLayout.DEFAULT_SIZE, 25, Short.MAX_VALUE)
                .addContainerGap())
        );

        jPanel_dashboard.setBackground(new java.awt.Color(46, 49, 49));
        jPanel_dashboard.setPreferredSize(new java.awt.Dimension(920, 493));

        jPanel5.setBackground(new java.awt.Color(247, 202, 24));

        jLabel11.setBackground(new java.awt.Color(245, 229, 27));
        jLabel11.setFont(new java.awt.Font("SansSerif", 0, 18)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(0, 0, 0));
        jLabel11.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel11.setText("Topp 3 agenter med flest aliens");
        jLabel11.setOpaque(true);

        jCombo_Omrade2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCombo_Omrade2ActionPerformed(evt);
            }
        });

        jTxt_TOP3.setEditable(false);
        jTxt_TOP3.setBackground(new java.awt.Color(247, 202, 24));
        jTxt_TOP3.setColumns(20);
        jTxt_TOP3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jTxt_TOP3.setRows(5);
        jScrollPane2.setViewportView(jTxt_TOP3);

        jButton1.setText("Välj område");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(33, 33, 33)
                        .addComponent(jCombo_Omrade2, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(43, 43, 43)
                        .addComponent(jButton1)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(31, 31, 31)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jCombo_Omrade2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 65, Short.MAX_VALUE)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(32, 32, 32))
        );

        jPanel3.setBackground(new java.awt.Color(247, 202, 24));

        jLabel9.setBackground(new java.awt.Color(245, 229, 27));
        jLabel9.setFont(new java.awt.Font("SansSerif", 0, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 0, 0));
        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel9.setText("Change password");
        jLabel9.setOpaque(true);

        jTxtNewPassword.setText("New password");
        jTxtNewPassword.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTxtNewPasswordActionPerformed(evt);
            }
        });

        jBtnPasswordChange.setText("Bekräfta");
        jBtnPasswordChange.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnPasswordChangeActionPerformed(evt);
            }
        });

        jLblDisplayPassword.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel9, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(72, 72, 72)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jBtnPasswordChange, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTxtNewPassword, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(72, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLblDisplayPassword)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLblDisplayPassword)
                .addGap(2, 2, 2)
                .addComponent(jTxtNewPassword, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jBtnPasswordChange, javax.swing.GroupLayout.DEFAULT_SIZE, 38, Short.MAX_VALUE)
                .addGap(12, 12, 12))
        );

        javax.swing.GroupLayout jPanel_dashboardLayout = new javax.swing.GroupLayout(jPanel_dashboard);
        jPanel_dashboard.setLayout(jPanel_dashboardLayout);
        jPanel_dashboardLayout.setHorizontalGroup(
            jPanel_dashboardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel_dashboardLayout.createSequentialGroup()
                .addContainerGap(158, Short.MAX_VALUE)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(66, 66, 66)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(144, 144, 144))
        );
        jPanel_dashboardLayout.setVerticalGroup(
            jPanel_dashboardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel_dashboardLayout.createSequentialGroup()
                .addGroup(jPanel_dashboardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel_dashboardLayout.createSequentialGroup()
                        .addGap(141, 141, 141)
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel_dashboardLayout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(95, Short.MAX_VALUE))
        );

        jPanel_Utrustning.setBackground(new java.awt.Color(46, 49, 49));
        jPanel_Utrustning.setForeground(new java.awt.Color(0, 0, 0));
        jPanel_Utrustning.setPreferredSize(new java.awt.Dimension(920, 493));
        jPanel_Utrustning.setRequestFocusEnabled(false);
        jPanel_Utrustning.setVerifyInputWhenFocusTarget(false);

        jPanel18.setBackground(new java.awt.Color(247, 202, 24));
        jPanel18.setPreferredSize(new java.awt.Dimension(294, 145));

        jLabel38.setBackground(new java.awt.Color(245, 229, 27));
        jLabel38.setFont(new java.awt.Font("SansSerif", 0, 18)); // NOI18N
        jLabel38.setForeground(new java.awt.Color(0, 0, 0));
        jLabel38.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel38.setText("Ta bort utrustning");
        jLabel38.setOpaque(true);

        jLbl_BenamningUtrustning1.setForeground(new java.awt.Color(0, 0, 0));
        jLbl_BenamningUtrustning1.setText("Benämning");

        jBtn_RegistreraUtrustning1.setText("Ta bort");
        jBtn_RegistreraUtrustning1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtn_RegistreraUtrustning1ActionPerformed(evt);
            }
        });

        jCombo_Utrustning1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCombo_Utrustning1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel18Layout = new javax.swing.GroupLayout(jPanel18);
        jPanel18.setLayout(jPanel18Layout);
        jPanel18Layout.setHorizontalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel38, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel18Layout.createSequentialGroup()
                .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel18Layout.createSequentialGroup()
                        .addGap(19, 19, 19)
                        .addComponent(jLbl_BenamningUtrustning1, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jCombo_Utrustning1, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel18Layout.createSequentialGroup()
                        .addGap(100, 100, 100)
                        .addComponent(jBtn_RegistreraUtrustning1))
                    .addGroup(jPanel18Layout.createSequentialGroup()
                        .addGap(68, 68, 68)
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(66, Short.MAX_VALUE))
        );
        jPanel18Layout.setVerticalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel18Layout.createSequentialGroup()
                .addComponent(jLabel38, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15)
                .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLbl_BenamningUtrustning1)
                    .addComponent(jCombo_Utrustning1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 0, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 27, Short.MAX_VALUE)
                .addComponent(jBtn_RegistreraUtrustning1)
                .addGap(22, 22, 22))
        );

        jPanel19.setBackground(new java.awt.Color(247, 202, 24));
        jPanel19.setPreferredSize(new java.awt.Dimension(294, 145));

        jLabel43.setBackground(new java.awt.Color(245, 229, 27));
        jLabel43.setFont(new java.awt.Font("SansSerif", 0, 18)); // NOI18N
        jLabel43.setForeground(new java.awt.Color(0, 0, 0));
        jLabel43.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel43.setText("Registrera ny utrustning");
        jLabel43.setOpaque(true);

        jLbl_BenamningUtrustning2.setForeground(new java.awt.Color(0, 0, 0));
        jLbl_BenamningUtrustning2.setText("Benämning");

        jBtn_RegistreraUtrustning2.setText("Registrera");
        jBtn_RegistreraUtrustning2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtn_RegistreraUtrustning2ActionPerformed(evt);
            }
        });

        jCombo_UtrustningTyp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCombo_UtrustningTypActionPerformed(evt);
            }
        });

        jLbl_BenamningUtrustning3.setForeground(new java.awt.Color(0, 0, 0));
        jLbl_BenamningUtrustning3.setText("Typ av utrustning");

        jLbl_typFraga.setForeground(new java.awt.Color(0, 0, 0));
        jLbl_typFraga.setText("Kraftkälla");

        jTxtTypFragaSvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTxtTypFragaSvarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel19Layout = new javax.swing.GroupLayout(jPanel19);
        jPanel19.setLayout(jPanel19Layout);
        jPanel19Layout.setHorizontalGroup(
            jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel43, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel19Layout.createSequentialGroup()
                .addGap(98, 98, 98)
                .addComponent(jBtn_RegistreraUtrustning2)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel19Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLbl_BenamningUtrustning2, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLbl_BenamningUtrustning3, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLbl_typFraga, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 39, Short.MAX_VALUE)
                .addGroup(jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jCombo_UtrustningTyp, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTxt_benamning, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTxtTypFragaSvar, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(35, 35, 35))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel19Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel19Layout.setVerticalGroup(
            jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel19Layout.createSequentialGroup()
                .addComponent(jLabel43, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15)
                .addGroup(jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLbl_BenamningUtrustning2)
                    .addComponent(jTxt_benamning, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jCombo_UtrustningTyp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLbl_BenamningUtrustning3))
                .addGap(18, 18, 18)
                .addGroup(jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLbl_typFraga)
                    .addComponent(jTxtTypFragaSvar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 0, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 25, Short.MAX_VALUE)
                .addComponent(jBtn_RegistreraUtrustning2)
                .addGap(18, 18, 18))
        );

        javax.swing.GroupLayout jPanel_UtrustningLayout = new javax.swing.GroupLayout(jPanel_Utrustning);
        jPanel_Utrustning.setLayout(jPanel_UtrustningLayout);
        jPanel_UtrustningLayout.setHorizontalGroup(
            jPanel_UtrustningLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel_UtrustningLayout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(jPanel19, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(76, 76, 76)
                .addComponent(jPanel18, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(231, Short.MAX_VALUE))
        );
        jPanel_UtrustningLayout.setVerticalGroup(
            jPanel_UtrustningLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel_UtrustningLayout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(jPanel_UtrustningLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel19, javax.swing.GroupLayout.PREFERRED_SIZE, 228, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel18, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(240, Short.MAX_VALUE))
        );

        jPanel_users.setBackground(new java.awt.Color(46, 49, 49));
        jPanel_users.setPreferredSize(new java.awt.Dimension(920, 493));

        jPanel11.setBackground(new java.awt.Color(247, 202, 24));

        jLabel19.setBackground(new java.awt.Color(245, 229, 27));
        jLabel19.setFont(new java.awt.Font("SansSerif", 0, 18)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(0, 0, 0));
        jLabel19.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel19.setText("Ändra info om alien");
        jLabel19.setOpaque(true);

        jCombo_ValjAlien2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCombo_ValjAlien2ActionPerformed(evt);
            }
        });

        jBtn_BekraftaSok.setText("Bekräfta");
        jBtn_BekraftaSok.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtn_BekraftaSokActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 0));
        jLabel2.setText("Välj alien:");

        jCheckBox1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jCheckBox1.setForeground(new java.awt.Color(0, 0, 0));
        jCheckBox1.setText("Nytt RegDatum:");
        jCheckBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox1ActionPerformed(evt);
            }
        });

        jCheckBox2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jCheckBox2.setForeground(new java.awt.Color(0, 0, 0));
        jCheckBox2.setText("Nytt lösenord:");
        jCheckBox2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox2ActionPerformed(evt);
            }
        });

        jCheckBox3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jCheckBox3.setForeground(new java.awt.Color(0, 0, 0));
        jCheckBox3.setText("Nytt namn:");
        jCheckBox3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox3ActionPerformed(evt);
            }
        });

        jCheckBox4.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jCheckBox4.setForeground(new java.awt.Color(0, 0, 0));
        jCheckBox4.setText("Nytt TelefonNr:");
        jCheckBox4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox4ActionPerformed(evt);
            }
        });

        jCheckBox5.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jCheckBox5.setForeground(new java.awt.Color(0, 0, 0));
        jCheckBox5.setText("Ny plats");
        jCheckBox5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox5ActionPerformed(evt);
            }
        });

        jCheckBox6.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jCheckBox6.setForeground(new java.awt.Color(0, 0, 0));
        jCheckBox6.setText("Ny AnsvarigAgent:");
        jCheckBox6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox6ActionPerformed(evt);
            }
        });

        jCheckBox7.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jCheckBox7.setForeground(new java.awt.Color(0, 0, 0));
        jCheckBox7.setText("Ny ras:");
        jCheckBox7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox7ActionPerformed(evt);
            }
        });

        jTxt_NyttLosenord.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTxt_NyttLosenordActionPerformed(evt);
            }
        });

        jCombo_Plats2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCombo_Plats2ActionPerformed(evt);
            }
        });

        jCombo_AnsvarigAgent2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCombo_AnsvarigAgent2ActionPerformed(evt);
            }
        });

        jCombo_Ras2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCombo_Ras2ActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 0, 0));
        jLabel7.setText("Välj ras:");

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel19, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel11Layout.createSequentialGroup()
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addGap(50, 50, 50)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jCombo_ValjAlien2, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel11Layout.createSequentialGroup()
                        .addGap(31, 31, 31)
                        .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(jCheckBox4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jCheckBox2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jCheckBox1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jCheckBox5, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jCheckBox6, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addComponent(jCheckBox3, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jCheckBox7, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 36, Short.MAX_VALUE)
                        .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTxt_NyttNamn, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTxt_NyttDatum, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTxt_NyttLosenord, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTxt_NyttNr, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jCombo_Plats2, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jCombo_AnsvarigAgent2, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jCombo_Ras2, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTxt_RasFraga2, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(53, 53, 53))
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addGap(73, 73, 73)
                        .addComponent(jLbl_MsgReg1, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addGap(116, 116, 116)
                        .addComponent(jBtn_BekraftaSok)))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jCombo_ValjAlien2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addGap(20, 20, 20)
                .addComponent(jLbl_MsgReg1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jCheckBox1)
                    .addComponent(jTxt_NyttDatum, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jCheckBox2)
                    .addComponent(jTxt_NyttLosenord, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jCheckBox3)
                    .addComponent(jTxt_NyttNamn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jCheckBox4)
                    .addComponent(jTxt_NyttNr, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jCheckBox5)
                    .addComponent(jCombo_Plats2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jCheckBox6)
                    .addComponent(jCombo_AnsvarigAgent2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jCheckBox7)
                    .addComponent(jCombo_Ras2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(jTxt_RasFraga2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jBtn_BekraftaSok)
                .addContainerGap())
        );

        jPanel12.setBackground(new java.awt.Color(247, 202, 24));

        jLabel20.setBackground(new java.awt.Color(245, 229, 27));
        jLabel20.setFont(new java.awt.Font("SansSerif", 0, 18)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(0, 0, 0));
        jLabel20.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel20.setText("Registrera ny alien");
        jLabel20.setOpaque(true);

        jLabel3.setForeground(new java.awt.Color(0, 0, 0));
        jLabel3.setText("Registreringsdatum");

        jLabel21.setForeground(new java.awt.Color(0, 0, 0));
        jLabel21.setText("Lösenord");

        jLabel22.setForeground(new java.awt.Color(0, 0, 0));
        jLabel22.setText("Namn");

        jLabel23.setForeground(new java.awt.Color(0, 0, 0));
        jLabel23.setText("Telefon");

        jLabel24.setForeground(new java.awt.Color(0, 0, 0));
        jLabel24.setText("Plats");

        jLabel25.setForeground(new java.awt.Color(0, 0, 0));
        jLabel25.setText("Ansvarig Agent");

        jBtn_Registrera1.setText("Registrera");
        jBtn_Registrera1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtn_Registrera1ActionPerformed(evt);
            }
        });

        jTxt_Datum.setText("yyyyMMdd");

        jLabel26.setForeground(new java.awt.Color(0, 0, 0));
        jLabel26.setText("Ras");

        jCombo_Plats1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCombo_Plats1ActionPerformed(evt);
            }
        });

        jCombo_Ras1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCombo_Ras1ActionPerformed(evt);
            }
        });

        jCombo_AnsvarigAgent1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCombo_AnsvarigAgent1ActionPerformed(evt);
            }
        });

        jLabel6.setForeground(new java.awt.Color(0, 0, 0));
        jLabel6.setText("Välj ras först");

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel20, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel12Layout.createSequentialGroup()
                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 69, Short.MAX_VALUE)
                                .addComponent(jTxt_Datum, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel12Layout.createSequentialGroup()
                                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel25, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel24, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel26, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jCombo_Ras1, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(jTxt_Namn, javax.swing.GroupLayout.DEFAULT_SIZE, 85, Short.MAX_VALUE)
                                        .addComponent(jTxt_Losenord)
                                        .addComponent(jTxt_Telefon)
                                        .addComponent(jCombo_Plats1, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(jCombo_AnsvarigAgent1, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jTxt_Rasfraga, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(35, 35, 35))))
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addGap(109, 109, 109)
                .addComponent(jBtn_Registrera1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addGap(73, 73, 73)
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLbl_RegConfirm, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLbl_MsgReg2, javax.swing.GroupLayout.DEFAULT_SIZE, 152, Short.MAX_VALUE))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15)
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jTxt_Datum, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel21)
                    .addComponent(jTxt_Losenord, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel22)
                    .addComponent(jTxt_Namn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel23)
                    .addComponent(jTxt_Telefon, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel24)
                    .addComponent(jCombo_Plats1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(21, 21, 21)
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel25)
                    .addComponent(jCombo_AnsvarigAgent1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel26)
                    .addComponent(jCombo_Ras1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(jTxt_Rasfraga, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLbl_RegConfirm)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jBtn_Registrera1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLbl_MsgReg2)
                .addGap(24, 24, 24))
        );

        javax.swing.GroupLayout jPanel_usersLayout = new javax.swing.GroupLayout(jPanel_users);
        jPanel_users.setLayout(jPanel_usersLayout);
        jPanel_usersLayout.setHorizontalGroup(
            jPanel_usersLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel_usersLayout.createSequentialGroup()
                .addGroup(jPanel_usersLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel_usersLayout.createSequentialGroup()
                        .addGap(33, 33, 33)
                        .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel_usersLayout.createSequentialGroup()
                        .addGap(60, 60, 60)
                        .addComponent(jLabel44, javax.swing.GroupLayout.PREFERRED_SIZE, 256, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 118, Short.MAX_VALUE)
                .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(121, 121, 121))
        );
        jPanel_usersLayout.setVerticalGroup(
            jPanel_usersLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel_usersLayout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(jPanel_usersLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel_usersLayout.createSequentialGroup()
                        .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel44))
                    .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(20, Short.MAX_VALUE))
        );

        jPanel_lista.setBackground(new java.awt.Color(46, 49, 49));
        jPanel_lista.setForeground(new java.awt.Color(0, 0, 0));
        jPanel_lista.setPreferredSize(new java.awt.Dimension(920, 493));

        jPanel14.setBackground(new java.awt.Color(247, 202, 24));

        jLabel39.setBackground(new java.awt.Color(245, 229, 27));
        jLabel39.setFont(new java.awt.Font("SansSerif", 0, 18)); // NOI18N
        jLabel39.setForeground(new java.awt.Color(0, 0, 0));
        jLabel39.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel39.setText("Lista");
        jLabel39.setOpaque(true);

        jLabel40.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel40.setForeground(new java.awt.Color(0, 0, 0));
        jLabel40.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel40.setText("Alla aliens på en plats");

        jLabel42.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel42.setForeground(new java.awt.Color(0, 0, 0));
        jLabel42.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel42.setText("Alla aliens av en ras");

        jLbl_ListaMellanDatum.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLbl_ListaMellanDatum.setForeground(new java.awt.Color(0, 0, 0));
        jLbl_ListaMellanDatum.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLbl_ListaMellanDatum.setText("Alla aliens registrerade mellan datumen");

        jBtn_Registrera4.setText("Lista");
        jBtn_Registrera4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtn_Registrera4ActionPerformed(evt);
            }
        });

        jBtn_listaBoglodite.setText("Boglodite");
        jBtn_listaBoglodite.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtn_listaBogloditeActionPerformed(evt);
            }
        });

        jBtn_Registrera8.setText("Lista");
        jBtn_Registrera8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtn_Registrera8ActionPerformed(evt);
            }
        });

        jCombo_Plats.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCombo_PlatsActionPerformed(evt);
            }
        });

        jBtn_listaSquid.setText("Squid");
        jBtn_listaSquid.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtn_listaSquidActionPerformed(evt);
            }
        });

        jBtn_listaWorm.setText("Worm");
        jBtn_listaWorm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtn_listaWormActionPerformed(evt);
            }
        });

        jTxt_listaDatum1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTxt_listaDatum1ActionPerformed(evt);
            }
        });

        jTxt_listaDatum2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTxt_listaDatum2ActionPerformed(evt);
            }
        });

        jLabel4.setForeground(new java.awt.Color(0, 0, 0));
        jLabel4.setText("Från datum");

        jLabel41.setForeground(new java.awt.Color(0, 0, 0));
        jLabel41.setText("Till datum");

        jLbl_ListaMellanDatum1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLbl_ListaMellanDatum1.setForeground(new java.awt.Color(0, 0, 0));
        jLbl_ListaMellanDatum1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLbl_ListaMellanDatum1.setText("Områdeschef på ett område");

        jCombo_Omrade1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCombo_Omrade1ActionPerformed(evt);
            }
        });

        jBtn_Registrera5.setText("Lista");
        jBtn_Registrera5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtn_Registrera5ActionPerformed(evt);
            }
        });

        jCombo_ValjAlien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCombo_ValjAlienActionPerformed(evt);
            }
        });

        jBtn_BekraftaSok1.setText("Bekräfta");
        jBtn_BekraftaSok1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtn_BekraftaSok1ActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 0));
        jLabel1.setText("Sök på specifik alien");

        jLabel15.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(0, 0, 0));
        jLabel15.setText("Lista utrustning jag lånar");

        jBtn_Utrustningen.setText("Lista");
        jBtn_Utrustningen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtn_UtrustningenActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel14Layout = new javax.swing.GroupLayout(jPanel14);
        jPanel14.setLayout(jPanel14Layout);
        jPanel14Layout.setHorizontalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel39, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel14Layout.createSequentialGroup()
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel14Layout.createSequentialGroup()
                        .addGap(38, 38, 38)
                        .addComponent(jLabel40, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel14Layout.createSequentialGroup()
                        .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel14Layout.createSequentialGroup()
                                .addGap(0, 11, Short.MAX_VALUE)
                                .addComponent(jLbl_ListaMellanDatum, javax.swing.GroupLayout.PREFERRED_SIZE, 252, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel14Layout.createSequentialGroup()
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jTxt_listaDatum1, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel14Layout.createSequentialGroup()
                                        .addComponent(jTxt_listaDatum2, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jBtn_Registrera8))
                                    .addComponent(jLabel41, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addGap(1, 1, 1))
                    .addGroup(jPanel14Layout.createSequentialGroup()
                        .addGap(0, 12, Short.MAX_VALUE)
                        .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel14Layout.createSequentialGroup()
                                .addComponent(jBtn_listaWorm)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jBtn_listaSquid)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jBtn_listaBoglodite))
                            .addComponent(jLabel42, javax.swing.GroupLayout.PREFERRED_SIZE, 252, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(27, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel14Layout.createSequentialGroup()
                .addGap(38, 38, 38)
                .addComponent(jCombo_Plats, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jBtn_Registrera4)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLbl_MsgReg4, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel14Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jCombo_ValjAlien, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jCombo_Omrade1, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jBtn_Registrera5, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jBtn_BekraftaSok1, javax.swing.GroupLayout.Alignment.TRAILING))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel14Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(85, 85, 85))
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel14Layout.createSequentialGroup()
                        .addGap(63, 63, 63)
                        .addComponent(jLbl_ListaMellanDatum1))
                    .addGroup(jPanel14Layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addComponent(jLabel15)
                        .addGap(18, 18, 18)
                        .addComponent(jBtn_Utrustningen)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel14Layout.setVerticalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addComponent(jLabel39, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addComponent(jLabel40)
                .addGap(11, 11, 11)
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jBtn_Registrera4)
                    .addComponent(jCombo_Plats, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10)
                .addComponent(jLabel42)
                .addGap(18, 18, 18)
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jBtn_listaBoglodite)
                    .addComponent(jBtn_listaSquid)
                    .addComponent(jBtn_listaWorm))
                .addGap(10, 10, 10)
                .addComponent(jLbl_ListaMellanDatum)
                .addGap(18, 18, 18)
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jLabel41))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTxt_listaDatum1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTxt_listaDatum2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jBtn_Registrera8))
                .addGap(18, 18, 18)
                .addComponent(jLbl_ListaMellanDatum1)
                .addGap(18, 18, 18)
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jBtn_Registrera5)
                    .addComponent(jCombo_Omrade1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jCombo_ValjAlien, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jBtn_BekraftaSok1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 12, Short.MAX_VALUE)
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel15)
                    .addComponent(jBtn_Utrustningen))
                .addGap(18, 18, 18)
                .addComponent(jLbl_MsgReg4))
        );

        jTxt_listaSvarRuta.setEditable(false);
        jTxt_listaSvarRuta.setBackground(new java.awt.Color(247, 202, 24));
        jTxt_listaSvarRuta.setColumns(20);
        jTxt_listaSvarRuta.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jTxt_listaSvarRuta.setRows(5);
        jTxt_listaSvarRuta.setMaximumSize(new java.awt.Dimension(32767, 32767));
        jTxt_listaSvarRuta.setMinimumSize(new java.awt.Dimension(0, 0));
        jTxt_listaSvarRuta.setPreferredSize(new java.awt.Dimension(279, 349));
        jScrollPane1.setViewportView(jTxt_listaSvarRuta);

        javax.swing.GroupLayout jPanel_listaLayout = new javax.swing.GroupLayout(jPanel_lista);
        jPanel_lista.setLayout(jPanel_listaLayout);
        jPanel_listaLayout.setHorizontalGroup(
            jPanel_listaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel_listaLayout.createSequentialGroup()
                .addGap(145, 145, 145)
                .addComponent(jPanel14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 56, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 294, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(145, 145, 145))
        );
        jPanel_listaLayout.setVerticalGroup(
            jPanel_listaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel_listaLayout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(jPanel_listaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 402, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(256, Short.MAX_VALUE))
        );

        jPanel_AdminMeny.setBackground(new java.awt.Color(46, 49, 49));
        jPanel_AdminMeny.setForeground(new java.awt.Color(0, 0, 0));
        jPanel_AdminMeny.setPreferredSize(new java.awt.Dimension(920, 493));

        jPanel8.setBackground(new java.awt.Color(247, 202, 24));

        jLabel34.setBackground(new java.awt.Color(245, 229, 27));
        jLabel34.setFont(new java.awt.Font("SansSerif", 0, 18)); // NOI18N
        jLabel34.setForeground(new java.awt.Color(0, 0, 0));
        jLabel34.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel34.setText("Sätt Områdeschef");
        jLabel34.setOpaque(true);

        jNamnPaAgent.setText("Agent namn");

        jAndraOmradesChef.setText("Bekräfta");
        jAndraOmradesChef.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jAndraOmradesChefActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel34, javax.swing.GroupLayout.DEFAULT_SIZE, 270, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jAndraOmradesChef, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jNamnPaAgent, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jCombo_Omrade5, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(36, 36, 36))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addComponent(jLabel34, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jNamnPaAgent, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jCombo_Omrade5, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 37, Short.MAX_VALUE)
                .addComponent(jAndraOmradesChef)
                .addGap(12, 12, 12))
        );

        jPanel9.setBackground(new java.awt.Color(247, 202, 24));

        jLabel35.setBackground(new java.awt.Color(245, 229, 27));
        jLabel35.setFont(new java.awt.Font("SansSerif", 0, 18)); // NOI18N
        jLabel35.setForeground(new java.awt.Color(0, 0, 0));
        jLabel35.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel35.setText("Ta bort Alien");
        jLabel35.setOpaque(true);

        jCombo_ValjAlien3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCombo_ValjAlien3ActionPerformed(evt);
            }
        });

        jButton5.setText("Bekräfta");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel35, javax.swing.GroupLayout.DEFAULT_SIZE, 270, Short.MAX_VALUE)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addComponent(jCombo_ValjAlien3, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addComponent(jLabel35, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(37, 37, 37)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton5)
                    .addComponent(jCombo_ValjAlien3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(46, Short.MAX_VALUE))
        );

        jPanel16.setBackground(new java.awt.Color(247, 202, 24));

        jLabel36.setBackground(new java.awt.Color(245, 229, 27));
        jLabel36.setFont(new java.awt.Font("SansSerif", 0, 18)); // NOI18N
        jLabel36.setForeground(new java.awt.Color(0, 0, 0));
        jLabel36.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel36.setText("Sätt Kontorschef");
        jLabel36.setOpaque(true);

        jNamnPaAgent2.setText("Agent namn");

        jButton3.setText("Bekräfta");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel16Layout = new javax.swing.GroupLayout(jPanel16);
        jPanel16.setLayout(jPanel16Layout);
        jPanel16Layout.setHorizontalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel36, javax.swing.GroupLayout.DEFAULT_SIZE, 270, Short.MAX_VALUE)
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addGap(38, 38, 38)
                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jButton3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jNamnPaAgent2, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jCombo_Kontor, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel16Layout.setVerticalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addComponent(jLabel36, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jCombo_Kontor, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jNamnPaAgent2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 37, Short.MAX_VALUE)
                .addComponent(jButton3)
                .addGap(12, 12, 12))
        );

        jPanel17.setBackground(new java.awt.Color(247, 202, 24));

        jLabel37.setBackground(new java.awt.Color(245, 229, 27));
        jLabel37.setFont(new java.awt.Font("SansSerif", 0, 18)); // NOI18N
        jLabel37.setForeground(new java.awt.Color(0, 0, 0));
        jLabel37.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel37.setText("Ta bort Agent");
        jLabel37.setOpaque(true);

        jCombo_ValjAgent2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCombo_ValjAgent2ActionPerformed(evt);
            }
        });

        jButton4.setText("Bekräfta");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel17Layout = new javax.swing.GroupLayout(jPanel17);
        jPanel17.setLayout(jPanel17Layout);
        jPanel17Layout.setHorizontalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel37, javax.swing.GroupLayout.DEFAULT_SIZE, 270, Short.MAX_VALUE)
            .addGroup(jPanel17Layout.createSequentialGroup()
                .addGap(42, 42, 42)
                .addComponent(jCombo_ValjAgent2, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel17Layout.setVerticalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel17Layout.createSequentialGroup()
                .addComponent(jLabel37, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 44, Short.MAX_VALUE)
                .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton4)
                    .addComponent(jCombo_ValjAgent2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(39, 39, 39))
        );

        javax.swing.GroupLayout jPanel_AdminMenyLayout = new javax.swing.GroupLayout(jPanel_AdminMeny);
        jPanel_AdminMeny.setLayout(jPanel_AdminMenyLayout);
        jPanel_AdminMenyLayout.setHorizontalGroup(
            jPanel_AdminMenyLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel_AdminMenyLayout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(jPanel_AdminMenyLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel17, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 49, Short.MAX_VALUE)
                .addGroup(jPanel_AdminMenyLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel16, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(309, 309, 309))
        );
        jPanel_AdminMenyLayout.setVerticalGroup(
            jPanel_AdminMenyLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel_AdminMenyLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(jPanel_AdminMenyLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel16, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(85, 85, 85)
                .addGroup(jPanel_AdminMenyLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel17, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(99, Short.MAX_VALUE))
        );

        jPanel_Agent.setBackground(new java.awt.Color(46, 49, 49));
        jPanel_Agent.setPreferredSize(new java.awt.Dimension(920, 493));

        jPanel13.setBackground(new java.awt.Color(247, 202, 24));

        jLabel27.setBackground(new java.awt.Color(245, 229, 27));
        jLabel27.setFont(new java.awt.Font("SansSerif", 0, 18)); // NOI18N
        jLabel27.setForeground(new java.awt.Color(0, 0, 0));
        jLabel27.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel27.setText("Ändra info om agent");
        jLabel27.setOpaque(true);

        jCombo_ValjAgent.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCombo_ValjAgentActionPerformed(evt);
            }
        });

        jBtn_BekraftaSok2.setText("Bekräfta");
        jBtn_BekraftaSok2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtn_BekraftaSok2ActionPerformed(evt);
            }
        });

        jLabel14.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(0, 0, 0));
        jLabel14.setText("Välj agent:");

        jCheckBox8.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jCheckBox8.setForeground(new java.awt.Color(0, 0, 0));
        jCheckBox8.setText("Nytt Ans.Datum:");
        jCheckBox8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox8ActionPerformed(evt);
            }
        });

        jCheckBox9.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jCheckBox9.setForeground(new java.awt.Color(0, 0, 0));
        jCheckBox9.setText("Nytt lösenord:");
        jCheckBox9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox9ActionPerformed(evt);
            }
        });

        jCheckBox10.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jCheckBox10.setForeground(new java.awt.Color(0, 0, 0));
        jCheckBox10.setText("Nytt namn:");
        jCheckBox10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox10ActionPerformed(evt);
            }
        });

        jCheckBox11.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jCheckBox11.setForeground(new java.awt.Color(0, 0, 0));
        jCheckBox11.setText("Nytt TelefonNr:");
        jCheckBox11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox11ActionPerformed(evt);
            }
        });

        jCheckBox12.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jCheckBox12.setForeground(new java.awt.Color(0, 0, 0));
        jCheckBox12.setText("Nytt område:");
        jCheckBox12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox12ActionPerformed(evt);
            }
        });

        jCheckBox13.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jCheckBox13.setForeground(new java.awt.Color(0, 0, 0));
        jCheckBox13.setText("Ny Adminstatus:");
        jCheckBox13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox13ActionPerformed(evt);
            }
        });

        jTxt_NyttLosenord1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTxt_NyttLosenord1ActionPerformed(evt);
            }
        });

        jCombo_Omrade4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCombo_Omrade4ActionPerformed(evt);
            }
        });

        jCombo_AdminStatus1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCombo_AdminStatus1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel27, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel13Layout.createSequentialGroup()
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel13Layout.createSequentialGroup()
                        .addGap(50, 50, 50)
                        .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jCombo_ValjAgent, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel13Layout.createSequentialGroup()
                        .addGap(31, 31, 31)
                        .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(jCheckBox11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jCheckBox9, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jCheckBox8, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jCheckBox12, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jCheckBox13, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addComponent(jCheckBox10, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 36, Short.MAX_VALUE)
                        .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTxt_NyttNamn1, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTxt_NyttDatum1, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTxt_NyttLosenord1, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTxt_NyttNr1, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jCombo_Omrade4, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jCombo_AdminStatus1, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(53, 53, 53))
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel13Layout.createSequentialGroup()
                        .addGap(73, 73, 73)
                        .addComponent(jLbl_MsgReg3, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel13Layout.createSequentialGroup()
                        .addGap(111, 111, 111)
                        .addComponent(jBtn_BekraftaSok2)))
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addGap(93, 93, 93)
                .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addComponent(jLabel27, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jCombo_ValjAgent, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel14))
                .addGap(20, 20, 20)
                .addComponent(jLbl_MsgReg3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jCheckBox8)
                    .addComponent(jTxt_NyttDatum1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jCheckBox9)
                    .addComponent(jTxt_NyttLosenord1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jCheckBox10)
                    .addComponent(jTxt_NyttNamn1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jCheckBox11)
                    .addComponent(jTxt_NyttNr1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jCheckBox12)
                    .addComponent(jCombo_Omrade4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jCheckBox13)
                    .addComponent(jCombo_AdminStatus1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(14, 14, 14)
                .addComponent(jLabel16)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jBtn_BekraftaSok2)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel15.setBackground(new java.awt.Color(247, 202, 24));

        jLabel28.setBackground(new java.awt.Color(245, 229, 27));
        jLabel28.setFont(new java.awt.Font("SansSerif", 0, 18)); // NOI18N
        jLabel28.setForeground(new java.awt.Color(0, 0, 0));
        jLabel28.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel28.setText("Registrera ny agent");
        jLabel28.setOpaque(true);

        jLabel17.setForeground(new java.awt.Color(0, 0, 0));
        jLabel17.setText("Anställningsdatum");

        jLabel29.setForeground(new java.awt.Color(0, 0, 0));
        jLabel29.setText("Lösenord");

        jLabel30.setForeground(new java.awt.Color(0, 0, 0));
        jLabel30.setText("Namn");

        jLabel31.setForeground(new java.awt.Color(0, 0, 0));
        jLabel31.setText("Telefon");

        jLabel32.setForeground(new java.awt.Color(0, 0, 0));
        jLabel32.setText("Område");

        jLabel33.setForeground(new java.awt.Color(0, 0, 0));
        jLabel33.setText("Administrator");

        jBtn_Registrera2.setText("Registrera");
        jBtn_Registrera2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtn_Registrera2ActionPerformed(evt);
            }
        });

        jTxt_Datum1.setText("yyyyMMdd");

        jCombo_Omrade3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCombo_Omrade3ActionPerformed(evt);
            }
        });

        jCombo_AdminStatus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCombo_AdminStatusActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel28, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 69, Short.MAX_VALUE)
                        .addComponent(jTxt_Datum1, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel15Layout.createSequentialGroup()
                        .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel29, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel33, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel30, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel31, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel32, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jTxt_Namn1, javax.swing.GroupLayout.DEFAULT_SIZE, 85, Short.MAX_VALUE)
                                .addComponent(jTxt_Losenord1)
                                .addComponent(jTxt_Telefon1)
                                .addComponent(jCombo_Omrade3, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jCombo_AdminStatus, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(35, 35, 35))
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addGap(73, 73, 73)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLbl_RegConfirm1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLbl_MsgReg5, javax.swing.GroupLayout.DEFAULT_SIZE, 152, Short.MAX_VALUE))
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addGap(109, 109, 109)
                .addComponent(jBtn_Registrera2)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addComponent(jLabel28, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel17)
                    .addComponent(jTxt_Datum1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel29)
                    .addComponent(jTxt_Losenord1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel30)
                    .addComponent(jTxt_Namn1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel31)
                    .addComponent(jTxt_Telefon1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel32)
                    .addComponent(jCombo_Omrade3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(21, 21, 21)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel33)
                    .addComponent(jCombo_AdminStatus, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(64, 64, 64)
                .addComponent(jLbl_RegConfirm1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jBtn_Registrera2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLbl_MsgReg5)
                .addGap(24, 24, 24))
        );

        javax.swing.GroupLayout jPanel_AgentLayout = new javax.swing.GroupLayout(jPanel_Agent);
        jPanel_Agent.setLayout(jPanel_AgentLayout);
        jPanel_AgentLayout.setHorizontalGroup(
            jPanel_AgentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel_AgentLayout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 129, Short.MAX_VALUE)
                .addComponent(jPanel13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(121, 121, 121))
        );
        jPanel_AgentLayout.setVerticalGroup(
            jPanel_AgentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel_AgentLayout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(jPanel_AgentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel15, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(66, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel_containerLayout = new javax.swing.GroupLayout(jPanel_container);
        jPanel_container.setLayout(jPanel_containerLayout);
        jPanel_containerLayout.setHorizontalGroup(
            jPanel_containerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel_containerLayout.createSequentialGroup()
                .addComponent(jPanel_menu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel_containerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel_dashboard, javax.swing.GroupLayout.PREFERRED_SIZE, 931, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
            .addGroup(jPanel_containerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel_containerLayout.createSequentialGroup()
                    .addContainerGap(228, Short.MAX_VALUE)
                    .addComponent(jPanel_users, javax.swing.GroupLayout.PREFERRED_SIZE, 931, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap()))
            .addGroup(jPanel_containerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel_containerLayout.createSequentialGroup()
                    .addContainerGap(228, Short.MAX_VALUE)
                    .addComponent(jPanel_Utrustning, javax.swing.GroupLayout.PREFERRED_SIZE, 931, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap()))
            .addGroup(jPanel_containerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel_containerLayout.createSequentialGroup()
                    .addContainerGap(228, Short.MAX_VALUE)
                    .addComponent(jPanel_lista, javax.swing.GroupLayout.PREFERRED_SIZE, 931, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap()))
            .addGroup(jPanel_containerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel_containerLayout.createSequentialGroup()
                    .addContainerGap(228, Short.MAX_VALUE)
                    .addComponent(jPanel_AdminMeny, javax.swing.GroupLayout.PREFERRED_SIZE, 931, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap()))
            .addGroup(jPanel_containerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel_containerLayout.createSequentialGroup()
                    .addContainerGap(233, Short.MAX_VALUE)
                    .addComponent(jPanel_Agent, javax.swing.GroupLayout.PREFERRED_SIZE, 916, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(16, 16, 16)))
        );
        jPanel_containerLayout.setVerticalGroup(
            jPanel_containerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel_menu, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel_containerLayout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel_dashboard, javax.swing.GroupLayout.PREFERRED_SIZE, 732, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .addGroup(jPanel_containerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel_containerLayout.createSequentialGroup()
                    .addContainerGap(43, Short.MAX_VALUE)
                    .addComponent(jPanel_users, 732, 732, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap()))
            .addGroup(jPanel_containerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel_containerLayout.createSequentialGroup()
                    .addContainerGap(43, Short.MAX_VALUE)
                    .addComponent(jPanel_Utrustning, javax.swing.GroupLayout.PREFERRED_SIZE, 732, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap()))
            .addGroup(jPanel_containerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel_containerLayout.createSequentialGroup()
                    .addContainerGap(43, Short.MAX_VALUE)
                    .addComponent(jPanel_lista, javax.swing.GroupLayout.PREFERRED_SIZE, 732, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap()))
            .addGroup(jPanel_containerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel_containerLayout.createSequentialGroup()
                    .addContainerGap(43, Short.MAX_VALUE)
                    .addComponent(jPanel_AdminMeny, javax.swing.GroupLayout.PREFERRED_SIZE, 732, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap()))
            .addGroup(jPanel_containerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel_containerLayout.createSequentialGroup()
                    .addContainerGap(46, Short.MAX_VALUE)
                    .addComponent(jPanel_Agent, javax.swing.GroupLayout.PREFERRED_SIZE, 719, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(16, 16, 16)))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel_container, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel_container, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    // Här skapar vi en metod för att kunna ändra lösenord
    private void jBtnPasswordChangeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnPasswordChangeActionPerformed
        String nyttpass = jTxtNewPassword.getText();
        String losenordQuery = "update agent\n" + "set Losenord = '" + nyttpass + "'" + "where Agent_ID = " + ID;
        String NewPassfraga = "SELECT Losenord from agent where Agent_ID = " + ID;
        String Newsvar = "x";
        if (Validation.textFieldHasValue(jTxtNewPassword)){
        try {
            idb.update(losenordQuery);
        } catch (InfException exn) {
            
        }
        try {
            idb.fetchSingle(NewPassfraga);
            Newsvar = idb.fetchSingle(NewPassfraga);

            if (Newsvar.equals(nyttpass)) {
                jLblDisplayPassword.setText("New password is: " + Newsvar);
            } else if (Validation.passwordLengthOk(Newsvar)) {
                JOptionPane.showMessageDialog(jLblDisplayPassword, "Max 6 chars på lösenordet");
            }
        } catch (InfException exn) {
            
        }}
        else{jLblDisplayPassword.setText("New password is too short");}
    }//GEN-LAST:event_jBtnPasswordChangeActionPerformed

    private void jTxtNewPasswordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTxtNewPasswordActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTxtNewPasswordActionPerformed

    // Listar alla aliens på en specifik plats
    private void jBtn_Registrera4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtn_Registrera4ActionPerformed
        jTxt_listaSvarRuta.setText("");
        String a = jCombo_Plats.getSelectedItem().toString();
        String fraga = "SELECT NAMN FROM ALIEN WHERE ALIEN.PLATS IN (SELECT PLATS_ID FROM PLATS WHERE PLATS.BENAMNING = '" + a + "')";
        ArrayList<HashMap<String, String>> alienList;

        try {
            alienList = idb.fetchRows(fraga);
            for (HashMap<String, String> h : alienList) {
                jTxt_listaSvarRuta.append(h.get("NAMN") + "\n");
            }

        } catch (InfException exb) {
            JOptionPane.showMessageDialog(null, exb);
        }

    }//GEN-LAST:event_jBtn_Registrera4ActionPerformed

    // Listar alla aliens av rastypen "Boglodite"
    private void jBtn_listaBogloditeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtn_listaBogloditeActionPerformed
        String fraga = "SELECT ALIEN.NAMN FROM ALIEN JOIN BOGLODITE ON ALIEN.ALIEN_ID = BOGLODITE.Alien_ID;";
        ArrayList<String> comboList;
        try {
            jTxt_listaSvarRuta.setText("");
            comboList = idb.fetchColumn(fraga);
            for (String s : comboList) {
                jTxt_listaSvarRuta.append(s + "\n");
            }
        } catch (InfException ex) {
            JOptionPane.showMessageDialog(null, "Felmeddelande:" + ex);
        }
    }//GEN-LAST:event_jBtn_listaBogloditeActionPerformed

    // Med denna metod kan användaren lista alla aliens som registrerats mellan två specifika datum
    private void jBtn_Registrera8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtn_Registrera8ActionPerformed
        jTxt_listaSvarRuta.setText("");
        String Datum1 = jTxt_listaDatum1.getText();
        String Datum2 = jTxt_listaDatum2.getText();
        String fraga = "SELECT Alien.namn FROM ALIEN WHERE registreringsdatum >=" + Datum1 + " and registreringsdatum <= " + Datum2;
       
        ArrayList<String> mellanDatum;
        
    if( (Datum1.length() < 9) && (Datum1.length() > 7) && (Datum2.length() < 9) && (Datum2.length() > 7)){
        try {
            jTxt_listaSvarRuta.setText("");
            mellanDatum = idb.fetchColumn(fraga);
            for (String s : mellanDatum) {
                jTxt_listaSvarRuta.append(s + "\n");
            }
        } catch (InfException ex) {
            JOptionPane.showMessageDialog(null, "Felmeddelande:" + ex);
        }
    }
    else { jTxt_listaSvarRuta.append("Vänligen skriv datum i formatet yyyyMMdd"); }
    }//GEN-LAST:event_jBtn_Registrera8ActionPerformed

    private void jCombo_PlatsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCombo_PlatsActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCombo_PlatsActionPerformed

    // Listar alla aliens av rastypen "Squid"
    private void jBtn_listaSquidActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtn_listaSquidActionPerformed
        String fraga = "SELECT ALIEN.NAMN FROM ALIEN JOIN SQUID ON ALIEN.ALIEN_ID = SQUID.Alien_ID;";
        ArrayList<String> comboList;
        try {
            jTxt_listaSvarRuta.setText("");
            comboList = idb.fetchColumn(fraga);
            for (String s : comboList) {
                jTxt_listaSvarRuta.append(s + "\n");
            }
        } catch (InfException ex) {
            JOptionPane.showMessageDialog(null, "Felmeddelande:" + ex);
        }
    }//GEN-LAST:event_jBtn_listaSquidActionPerformed

    // Listar alla aliens av rastypen "Worm"
    private void jBtn_listaWormActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtn_listaWormActionPerformed
        String fraga = "SELECT ALIEN.NAMN FROM ALIEN JOIN WORM ON ALIEN.ALIEN_ID = WORM.Alien_ID;";
        ArrayList<String> comboList;
        try {
            jTxt_listaSvarRuta.setText("");
            comboList = idb.fetchColumn(fraga);
            for (String s : comboList) {
                jTxt_listaSvarRuta.append(s + "\n");
            }
        } catch (InfException ex) {
            JOptionPane.showMessageDialog(null, "Felmeddelande:" + ex);
        }
    }//GEN-LAST:event_jBtn_listaWormActionPerformed

    private void jTxt_listaDatum1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTxt_listaDatum1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTxt_listaDatum1ActionPerformed

    private void jCombo_Omrade1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCombo_Omrade1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCombo_Omrade1ActionPerformed

    // Här listas områdeschefen över ett specifikt område
    private void jBtn_Registrera5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtn_Registrera5ActionPerformed
        jTxt_listaSvarRuta.setText("");
        String omradesChef = "";
        String selected = jCombo_Omrade1.getSelectedItem().toString();
        String fraga = String.format(
                """
                SELECT agent.namn 
                FROM Agent 
                join omradeschef on agent.Agent_ID = omradeschef.Agent_ID 
                join omrade on omradeschef.Omrade = omrade.Omrades_ID 
                WHERE omrade.Benamning = '%s' """,
                selected);
        try {
            omradesChef = idb.fetchSingle(fraga);
            jTxt_listaSvarRuta.setText(omradesChef);
        } catch (InfException exb) {
            JOptionPane.showMessageDialog(null, exb);
        }
    }//GEN-LAST:event_jBtn_Registrera5ActionPerformed
//alla "TömCombo..." tömmer combolistorna
    private void tömComboBoxUtrustning() {

                jCombo_Utrustning1.removeAllItems();

        }
    private void tömComboBoxValjAlien() {

                jCombo_ValjAlien.removeAllItems();
                jCombo_ValjAlien2.removeAllItems();

        }
    private void tömComboBoxAgent() {

                jCombo_AnsvarigAgent1.removeAllItems();
                jCombo_AnsvarigAgent2.removeAllItems();
                jCombo_ValjAgent.removeAllItems();

        }
    //Alla "FyllCombo..." fyller combolistorna
    private void fyllComboBoxUtrustning() {
        String fraga = "SELECT BENAMNING FROM utrustning";
        ArrayList<String> utrustningcomboList;

        try {
            utrustningcomboList = idb.fetchColumn(fraga);
            for (String s : utrustningcomboList) {
                jCombo_Utrustning1.addItem(s);
            }
        } catch (InfException ex) {
            JOptionPane.showMessageDialog(null, "Felmeddelande:" + ex);

        }
    }

    private void fyllComboBoxOmrade() {

        String fraga = "SELECT BENAMNING FROM omrade";
        ArrayList<String> omradecomboList;
        try {

            omradecomboList = idb.fetchColumn(fraga);
            for (String s : omradecomboList) {
                jCombo_Omrade1.addItem(s);
                jCombo_Omrade2.addItem(s);
                jCombo_Omrade3.addItem(s);
                jCombo_Omrade4.addItem(s);
                jCombo_Omrade5.addItem(s);
            }
        } catch (InfException ex) {
            JOptionPane.showMessageDialog(null, "Felmeddelande:" + ex);

        }
    }

    private void fyllComboBoxKontor() {

        String fraga = "SELECT kontorsbeteckning FROM kontorschef";
        ArrayList<String> comboList;
        try {

            comboList = idb.fetchColumn(fraga);
            for (String s : comboList) {
                jCombo_Kontor.addItem(s);
            }
        } catch (InfException ex) {
            JOptionPane.showMessageDialog(null, "Felmeddelande:" + ex);

        }
    }
    
    private void fyllComboBoxPlats() {

        String fraga = "SELECT BENAMNING FROM PLATS";
        ArrayList<String> comboList;
        try {

            comboList = idb.fetchColumn(fraga);
            for (String s : comboList) {
                jCombo_Plats.addItem(s);
                jCombo_Plats1.addItem(s);
                jCombo_Plats2.addItem(s);
            }
        } catch (InfException ex) {
            JOptionPane.showMessageDialog(null, "Felmeddelande:" + ex);

        }
    }

    private void fyllComboBoxValjAlien() {

        String fraga = "SELECT alien.Namn FROM alien";
        ArrayList<String> comboList;

        try {

            comboList = idb.fetchColumn(fraga);
            for (String s : comboList) {
                jCombo_ValjAlien.addItem(s);
                jCombo_ValjAlien2.addItem(s);
                jCombo_ValjAlien3.addItem(s);
            }
        } catch (InfException ex) {
            JOptionPane.showMessageDialog(null, "Felmeddelande:" + ex);

        }
    }

    private void fyllComboBoxAgent() {

        String fraga = "SELECT Agent.Namn FROM agent";
        ArrayList<String> comboList;
        try {

            comboList = idb.fetchColumn(fraga);
            for (String s : comboList) {
                jCombo_AnsvarigAgent1.addItem(s);
                jCombo_AnsvarigAgent2.addItem(s);
                jCombo_ValjAgent.addItem(s);
                jCombo_ValjAgent2.addItem(s);
            }
        } catch (InfException ex) {
            JOptionPane.showMessageDialog(null, "Felmeddelande:" + ex);

        }
    }

    private void jCombo_ValjAlien2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCombo_ValjAlien2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCombo_ValjAlien2ActionPerformed

    // Med denna metod kan användaren ändra information om en redan befintlig alien
    private void jBtn_BekraftaSokActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtn_BekraftaSokActionPerformed
        String id = "";
        String currentname = jCombo_ValjAlien2.getSelectedItem().toString();
        String datum = jTxt_NyttDatum.getText();
        String Losenord = jTxt_NyttLosenord.getText();
        String Aliennamn = jTxt_NyttNamn.getText();
        String telefon = jTxt_NyttNr.getText();
        String plats = jCombo_Plats2.getSelectedItem().toString();
        String agent = jCombo_AnsvarigAgent2.getSelectedItem().toString();
        String ras = jCombo_Ras2.getSelectedItem().toString();
        String Bogolite = "BOGLODITE";
        String Worm = "Worm";
        String squid = "SQUID";
        String Rasfraga = jTxt_RasFraga2.getText();
        String HittaID = "SELECT Alien_ID from Alien where namn = '" + currentname + "'";

        try {
            id = idb.fetchSingle(HittaID);

            System.out.print("UPDATE ALIEN SET NAMN = " + Aliennamn + " WHERE ALIEN_ID = " + id);
            String agentId = idb.fetchSingle("select agent_id from agent where namn = '" + agent + "'");
            String platsId = idb.fetchSingle("select plats_id from plats where benamning = '" + plats + "'");

            if (jCheckBox1.isSelected()) {
                String query = "UPDATE ALIEN SET REGISTRERINGSDATUM = " + datum + " WHERE ALIEN_ID = " + id;
                idb.update(query);
                System.out.println(query);
            }

            if (jCheckBox2.isSelected()) {
                if(Losenord.length() > 0){
                idb.update("UPDATE ALIEN SET losenord = '" + Losenord + "' WHERE ALIEN_ID = " + id);
            }

            else {jLabel44.setText("Lösenordet får inte vara tomt");}
            }
            

            if (jCheckBox3.isSelected()) {
                 if(Aliennamn.length() > 0){
                idb.update("UPDATE ALIEN SET NAMN = '" + Aliennamn + "' WHERE ALIEN_ID = " + id);
            }

            else {jLabel44.setText("Namnet får inte vara tomt");}
            }

            if (jCheckBox4.isSelected()) {
                idb.update("UPDATE ALIEN SET TELEFON = '" + telefon + "' WHERE ALIEN_ID = " + id);
            }
            if (jCheckBox5.isSelected()) {
                idb.update("UPDATE ALIEN SET PLATS = '" + platsId + "' WHERE ALIEN_ID = " + id);
            }
            if (jCheckBox6.isSelected()) {
                idb.update("UPDATE ALIEN SET ANSVARIG_AGENT = '" + agentId + "' WHERE ALIEN_ID = " + id);
            }

            if (jCheckBox7.isSelected()) {

                idb.delete("DELETE FROM worm WHERE ALIEN_ID = " + id);
                idb.delete("DELETE FROM boglodite WHERE ALIEN_ID = " + id);
                idb.delete("DELETE FROM squid WHERE ALIEN_ID = " + id);

                if (ras.equalsIgnoreCase(Bogolite)) {
                    String AddBoglodite = "INSERT INTO boglodite Values(" + id + ", " + Rasfraga + ")";
                    try {
                        idb.insert(AddBoglodite);

                    } catch (Exception e) {
                    }
                }
                if (ras.equalsIgnoreCase(squid)) {
                    String AddSquid = "INSERT INTO squid Values(" + id + ", " + Rasfraga + ")";
                    try {
                        idb.insert(AddSquid);

                    } catch (Exception e) {
                    }
                }
                if (ras.equalsIgnoreCase(Worm)) {
                    String AddWorm = "INSERT INTO worm Values(" + id + ")";
                    try {
                        idb.insert(AddWorm);

                    } catch (Exception e) {
                    }
                }
            }
        } catch (InfException ex) {

        }
    tömComboBoxValjAlien();
    fyllComboBoxValjAlien();
    }//GEN-LAST:event_jBtn_BekraftaSokActionPerformed

    // Metod som tillåter användaren att registrera en ny alien
    private void jBtn_Registrera1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtn_Registrera1ActionPerformed
        String Alien_ID = "";
        String Losenord = jTxt_Losenord.getText();
        String Namn = jTxt_Namn.getText();
        String Telefon = jTxt_Telefon.getText();
        String Plats = jCombo_Plats1.getSelectedItem().toString();
        String AnsvarigAgent = jCombo_AnsvarigAgent1.getSelectedItem().toString();
        String Ras = jCombo_Ras1.getSelectedItem().toString();
        String Rasfraga = jTxt_Rasfraga.getText();
        String PlatsID = "";
        String AgentID = "";
        String Bogolite = "BOGLODITE";
        String Worm = "Worm";
        String squid = "SQUID";
        String Registreringsdatum = jTxt_Datum.getText();
        if (!Ras.isEmpty() & !AnsvarigAgent.isEmpty()) {

            if (Validation.textFieldHasValue(jTxt_Losenord) && Validation.textFieldHasValue(jTxt_Namn) && Validation.passwordLengthOk(Losenord)) {
                String fragaplats = "SELECT Plats_ID from plats WHERE Benamning = '" + Plats + "'";
                String fragaAgent = "SELECT agent_ID from agent WHERE Namn = '" + AnsvarigAgent + "'";
                String AddAlien = "INSERT INTO Alien Values (" + Alien_ID + ", "
                        + Registreringsdatum + ", '" + Losenord + "', '" + Namn + "', " + Telefon + ", " + PlatsID + ", " + AgentID + ")";

                try {
                    PlatsID = idb.fetchSingle(fragaplats);
                    Alien_ID = idb.getAutoIncrement("Alien", "Alien_ID");
                    AgentID = idb.fetchSingle(fragaAgent);
                    idb.insert(AddAlien);

                    if (Ras.equalsIgnoreCase(Bogolite)) {
                        String AddBoglodite = "INSERT INTO boglodite Values(" + Alien_ID + ", " + Rasfraga + ")";

                        idb.insert(AddBoglodite);

                    }
                    if (Ras.equalsIgnoreCase(squid)) {
                        String AddSquid = "INSERT INTO squid Values(" + Alien_ID + ", " + Rasfraga + ")";

                        idb.insert(AddSquid);

                    }
                    if (Ras.equalsIgnoreCase(Worm)) {
                        String AddWorm = "INSERT INTO worm Values(" + Alien_ID + ")";

                        idb.insert(AddWorm);

                    }
                } catch (Exception exn) {
                    
                }
            }
        }
        jLbl_RegConfirm.setText("Alien har registrerats");
    tömComboBoxValjAlien();
    fyllComboBoxValjAlien();
    }//GEN-LAST:event_jBtn_Registrera1ActionPerformed

    private void jCombo_ValjAlienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCombo_ValjAlienActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCombo_ValjAlienActionPerformed

    // Med denna metod listas all information om en specifik alien
    private void jBtn_BekraftaSok1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtn_BekraftaSok1ActionPerformed
        String Namnet = jCombo_ValjAlien.getSelectedItem().toString();
        String telefon = "";
        String datum = "";
        String losenord = "";
        String plats = "";
        String ansvarigAgent = "";
        String id = "";
        String ras = "";

        jTxt_listaSvarRuta.setText("");

        try {
            String query = String.format(
                    """
                        select al.*, ag.Namn AS `AgentNamn`, p.Benamning AS `Plats`
                        from Alien al
                        join Agent ag on ag.Agent_ID = al.Ansvarig_Agent
                        join Plats p on al.Plats = p.Plats_ID
                        where al.Namn = '%s';
                    """, Namnet
            );
            
            HashMap<String, String> dbResult = idb.fetchRow(query);
            
            Namnet = dbResult.get("Namn");
            telefon = dbResult.get("Telefon");
            datum = dbResult.get("Registreringsdatum");
            losenord = dbResult.get("Losenord");
            plats = dbResult.get("Benamning");
            ansvarigAgent = dbResult.get("AgentNamn");
            id = dbResult.get("Alien_ID");
            ras = getRasen(id);
            idb.update(ansvarigAgent);
        } catch (Exception exn) {
            
        }

        String resultat = "Namn: " + Namnet + "\n" + "telefon: " + telefon + "\n"
                + "registreringsdatum: " + datum + "\n" + "lösenord: " + losenord + "\n" + "plats: " + plats
                + "\n" + "ansvarig agent: " + ansvarigAgent + "\n" + "alien id: " + id + "\n" + "ras: " + ras;
        jTxt_listaSvarRuta.setText(resultat);
    }//GEN-LAST:event_jBtn_BekraftaSok1ActionPerformed

    private void jCheckBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCheckBox1ActionPerformed

    private void jCheckBox2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCheckBox2ActionPerformed

    private void jCheckBox3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCheckBox3ActionPerformed

    private void jCheckBox4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCheckBox4ActionPerformed

    private void jCheckBox5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCheckBox5ActionPerformed

    private void jCheckBox6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox6ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCheckBox6ActionPerformed

    private void jCheckBox7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox7ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCheckBox7ActionPerformed

    private void jCombo_Plats2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCombo_Plats2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCombo_Plats2ActionPerformed

    private void jCombo_AnsvarigAgent2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCombo_AnsvarigAgent2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCombo_AnsvarigAgent2ActionPerformed

    private void jCombo_Ras2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCombo_Ras2ActionPerformed
        String Bogolite = "BOGLODITE";
        String Worm = "Worm";
        String squid = "SQUID";
        String Ras = jCombo_Ras2.getSelectedItem().toString();
        if (Ras.equalsIgnoreCase(Bogolite)) {
            jLabel7.setText("Antal boogies:");
        }
        if (Ras.equalsIgnoreCase(Worm)) {
            jLabel7.setText("Worm vald");
        }
        if (Ras.equalsIgnoreCase(squid)) {
            jLabel7.setText("Antal Armar:");
        }
    }//GEN-LAST:event_jCombo_Ras2ActionPerformed

    private void jCombo_Plats1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCombo_Plats1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCombo_Plats1ActionPerformed

    private void jCombo_Ras1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCombo_Ras1ActionPerformed
        String Bogolite = "BOGLODITE";
        String Worm = "Worm";
        String squid = "SQUID";
        String Ras = jCombo_Ras1.getSelectedItem().toString();
        if (Ras.equalsIgnoreCase(Bogolite)) {
            jLabel6.setText("Antal boogies:");
        }
        if (Ras.equalsIgnoreCase(Worm)) {
            jLabel6.setText("Worm vald");
        }
        if (Ras.equalsIgnoreCase(squid)) {
            jLabel6.setText("Antal Armar:");
        }
    }//GEN-LAST:event_jCombo_Ras1ActionPerformed

    private void jCombo_AnsvarigAgent1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCombo_AnsvarigAgent1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCombo_AnsvarigAgent1ActionPerformed

    private void jTxt_NyttLosenordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTxt_NyttLosenordActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTxt_NyttLosenordActionPerformed

    // Lista utrustning som agenten/användaren just nu lånar
    private void jBtn_UtrustningenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtn_UtrustningenActionPerformed
        jTxt_listaSvarRuta.setText("");
        ArrayList<HashMap<String, String>> alienList;
        String fraga = String.format(
                """
                    SELECT utrustning.Benamning from utrustning
                    join innehar_utrustning iu on utrustning.Utrustnings_ID = iu.Utrustnings_ID
                    join agent a on iu.Agent_ID = a.Agent_ID
                    where a.Agent_ID = %s
                """, ID);
        try {
            alienList = idb.fetchRows(fraga);
            for (HashMap<String, String> h : alienList) {
                jTxt_listaSvarRuta.append(h.get("Benamning") + "\n");
            }
        } catch (InfException exb) {
            JOptionPane.showMessageDialog(null, exb);
        }
    }//GEN-LAST:event_jBtn_UtrustningenActionPerformed

    private void jCombo_Omrade2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCombo_Omrade2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCombo_Omrade2ActionPerformed

    // Med denna metod kan man lista top 3 listor på agenter som ansvarar över flest aliens inom ett specifikt område.
    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        jTxt_TOP3.setText("");
        String omradet = jCombo_Omrade2.getSelectedItem().toString();
        ArrayList<HashMap<String, String>> Toplistan;
        String fraga = String.format(
                """
                    SELECT agent.namn, COUNT(`Ansvarig_Agent`) AS `Antal aliens`
                    FROM Agent
                    JOIN alien a ON agent.Agent_ID = a.Ansvarig_Agent
                    JOIN omrade o ON agent.Omrade = o.Omrades_ID
                    where o.Benamning = '%s'
                    GROUP BY Ansvarig_Agent
                    ORDER BY COUNT(`Ansvarig_Agent`) desc
                    LIMIT 3
                """,
                omradet);
        
        try {
            Toplistan = idb.fetchRows(fraga);
            for (HashMap<String, String> h : Toplistan) {
                jTxt_TOP3.append(h.get("namn") + " ansvarar för : " + h.get("Antal aliens") + " aliens \n");
            }
            if(Toplistan.isEmpty()){jTxt_TOP3.setText("Ingen agent med aliens");}
        } catch (InfException exb) {
            JOptionPane.showMessageDialog(null, exb);
        }
        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jCombo_ValjAgentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCombo_ValjAgentActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCombo_ValjAgentActionPerformed

    // Med denna metod kan man ändra information om en redan befintlig agent
    private void jBtn_BekraftaSok2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtn_BekraftaSok2ActionPerformed
        String id = "";
        String currentname = jCombo_ValjAgent.getSelectedItem().toString();
        String datum = jTxt_NyttDatum1.getText();
        String Losenord = jTxt_NyttLosenord1.getText();
        String Agentnamn = jTxt_NyttNamn1.getText();
        String telefon = jTxt_NyttNr1.getText();
        String omrade = jCombo_Omrade4.getSelectedItem().toString();
        String AdminStatus = jCombo_AdminStatus1.getSelectedItem().toString();
        String HittaID = "SELECT Agent_ID from Agent where namn = '" + currentname + "'";
        String fragaomradeId = "select omrades_id from omrade where benamning = '" + omrade + "'";
        String fårinte = "system";
    if(Agentnamn.equalsIgnoreCase(fårinte)){JOptionPane.showMessageDialog(null, "Du får inte ta bort system"); }
        else{
        try {
            id = idb.fetchSingle(HittaID);
            String omradesvar = idb.fetchSingle(fragaomradeId);

            if (jCheckBox8.isSelected() ) {
                String query = "UPDATE Agent SET Anstallningsdatum = " + datum + " WHERE Agent_ID = " + id;
                idb.update(query);
                System.out.println(query);
            }

            if (jCheckBox9.isSelected() ) {
                idb.update("UPDATE Agent SET losenord = '" + Losenord + "' WHERE Agent_ID = " + id);
            }

            if (jCheckBox10.isSelected() ) {
                idb.update("UPDATE Agent SET NAMN = '" + Agentnamn + "' WHERE Agent_ID = " + id);
            }

            if (jCheckBox11.isSelected() ) {
                idb.update("UPDATE Agent SET TELEFON = '" + telefon + "' WHERE Agent_ID = " + id);
            }
            if (jCheckBox12.isSelected() ) {
                idb.update("UPDATE Agent SET Omrade = " + omradesvar + " WHERE Agent_ID = " + id);
            }
            if (jCheckBox13.isSelected() ) {
                idb.update("UPDATE Agent SET Administrator = '" + AdminStatus + "' WHERE Agent_ID = " + id);
            }

        } catch (Exception exn) {
            
        }
        jLabel16.setText("Agent Uppdaterad");
        tömComboBoxAgent();
        fyllComboBoxAgent();
    }
    }//GEN-LAST:event_jBtn_BekraftaSok2ActionPerformed

    private void jCheckBox8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox8ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCheckBox8ActionPerformed

    private void jCheckBox9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox9ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCheckBox9ActionPerformed

    private void jCheckBox10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox10ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCheckBox10ActionPerformed

    private void jCheckBox11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox11ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCheckBox11ActionPerformed

    private void jCheckBox12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox12ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCheckBox12ActionPerformed

    private void jTxt_NyttLosenord1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTxt_NyttLosenord1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTxt_NyttLosenord1ActionPerformed

    private void jCombo_Omrade4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCombo_Omrade4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCombo_Omrade4ActionPerformed

    // Med denna metod kan man registrera en ny agent
    private void jBtn_Registrera2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtn_Registrera2ActionPerformed
        String Agent_ID = "";
        String Losenord = jTxt_Losenord1.getText();
        String Namn = jTxt_Namn1.getText();
        String Telefon = jTxt_Telefon1.getText();
        String omrade = jCombo_Omrade3.getSelectedItem().toString();
        String omradesID = "";
        String Anstallningsdatum = jTxt_Datum1.getText();
        String AdminStatus = jCombo_AdminStatus.getSelectedItem().toString();
        if (!omrade.isEmpty() & !AdminStatus.isEmpty()) {
            if (Validation.textFieldHasValue(jTxt_Losenord1) && Validation.textFieldHasValue(jTxt_Namn1) && Validation.passwordLengthOk(Losenord)) {
                String fragaomrade = "SELECT omrades_ID from omrade WHERE Benamning = '" + omrade + "'";

                try {
                    omradesID = idb.fetchSingle(fragaomrade);
                    Agent_ID = idb.getAutoIncrement("Agent", "Agent_ID");
                    String AddAgent = "INSERT INTO Agent Values (" + Agent_ID + ", '" + Namn + "', '" + Telefon + "', '" + Anstallningsdatum + "', '" + AdminStatus + "', '" + Losenord + "', " + omradesID + ")";
                    System.out.print(AddAgent);
                    idb.insert(AddAgent);
                    jLbl_RegConfirm1.setText("Agent har registrerats");
                } catch (Exception exn) {
                    
                }
            }
        }
        if(!Validation.passwordLengthOk(Losenord)){jLbl_RegConfirm1.setText("endast 6 bokstäver i lösenord");}
        
        tömComboBoxAgent();
        fyllComboBoxAgent();
    }//GEN-LAST:event_jBtn_Registrera2ActionPerformed

    private void jCombo_Omrade3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCombo_Omrade3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCombo_Omrade3ActionPerformed

    private void jCombo_AdminStatusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCombo_AdminStatusActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCombo_AdminStatusActionPerformed

    private void jCombo_AdminStatus1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCombo_AdminStatus1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCombo_AdminStatus1ActionPerformed

    private void jCheckBox13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox13ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCheckBox13ActionPerformed

    // I denna metod kan användaren ta bort utrustning ur systemet
    private void jBtn_RegistreraUtrustning1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtn_RegistreraUtrustning1ActionPerformed
        String UID = "";
        String Utrustningen = jCombo_Utrustning1.getSelectedItem().toString();
        String fragaID = "SELECT Utrustnings_ID from Utrustning WHERE Benamning = '" + Utrustningen + "'";

        try {
            UID = idb.fetchSingle(fragaID);
            idb.delete("delete from kommunikation where Utrustnings_ID = " + UID);
            idb.delete("delete from vapen where Utrustnings_ID = " + UID);
            idb.delete("delete from teknik where Utrustnings_ID = " + UID);
            idb.delete("delete from utrustning where Utrustnings_ID = " + UID);
        } catch (Exception exn) {
            
        }

        jLabel5.setText("Utrustningen borttagen");
        tömComboBoxUtrustning();
        fyllComboBoxUtrustning();
    }//GEN-LAST:event_jBtn_RegistreraUtrustning1ActionPerformed

    private void jCombo_Utrustning1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCombo_Utrustning1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCombo_Utrustning1ActionPerformed

    // Med denna metod tillåts användaren att registrera ny utrustning
    private void jBtn_RegistreraUtrustning2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtn_RegistreraUtrustning2ActionPerformed
        String benamning = jTxt_benamning.getText();
        String Utrustnings_ID = "";
        String vapen = "vapen";
        String teknik = "teknik";
        String kommunikation = "kommunikation";
        String Typ = jCombo_UtrustningTyp.getSelectedItem().toString();
        String Typfragasvar = jTxtTypFragaSvar.getText();

        try {
            Utrustnings_ID = idb.getAutoIncrement("Utrustning", "Utrustnings_ID");
            String AddUtrustning = "INSERT INTO Utrustning Values (" + Utrustnings_ID + ", '" + benamning + "')";
            idb.insert(AddUtrustning);

            if (Typ.equalsIgnoreCase(vapen) && Validation.textFieldHasValue(jTxtTypFragaSvar) && Validation.isNumber(Typfragasvar)) {
                String Addvapen = "INSERT INTO vapen Values(" + Utrustnings_ID + ", " + Typfragasvar + ")";

                idb.insert(Addvapen);

            }
            if (Typ.equalsIgnoreCase(teknik) && Validation.textFieldHasValue(jTxtTypFragaSvar)) {
                String Addteknik = "INSERT INTO teknik Values(" + Utrustnings_ID + ", " + Typfragasvar + ")";

                idb.insert(Addteknik);

            }
            if (Typ.equalsIgnoreCase(kommunikation) && Validation.textFieldHasValue(jTxtTypFragaSvar)) {
                String Addkommunikation = "INSERT INTO kommunikation Values (" + Utrustnings_ID + ", " + Typfragasvar + ")";

                idb.insert(Addkommunikation);

            }
        } catch (Exception exn) {
        }
        jLabel18.setText("Utrustningen registrerad");
        tömComboBoxUtrustning();
        fyllComboBoxUtrustning();
    }//GEN-LAST:event_jBtn_RegistreraUtrustning2ActionPerformed

    private void jCombo_UtrustningTypActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCombo_UtrustningTypActionPerformed
        String vapen = "vapen";
        String teknik = "teknik";
        String kommunikation = "kommunikation";
        String Typ = jCombo_UtrustningTyp.getSelectedItem().toString();
        if (Typ.equalsIgnoreCase(vapen)) {
            jLbl_typFraga.setText("Kaliber");
        }
        if (Typ.equalsIgnoreCase(teknik)) {
            jLbl_typFraga.setText("Kraftkälla");
        }
        if (Typ.equalsIgnoreCase(kommunikation)) {
            jLbl_typFraga.setText("Överföringsteknik");
        }
    }//GEN-LAST:event_jCombo_UtrustningTypActionPerformed

    private void jTxtTypFragaSvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTxtTypFragaSvarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTxtTypFragaSvarActionPerformed

    // Ändrar områdeschef över ett specifikt område
    private void jAndraOmradesChefActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jAndraOmradesChefActionPerformed

        if (Validation.textFieldHasValue(jNamnPaAgent)){

            try {
                String hittaAgentId = idb.fetchSingle("SELECT AGENT_ID FROM AGENT WHERE NAMN ='" + jNamnPaAgent.getText() + "'");
                if(hittaAgentId != null)
                {
                    if(jCombo_Omrade5.getSelectedItem().toString().equals("Götaland")){
                        String agentId = idb.fetchSingle("SELECT AGENT_ID FROM OMRADESCHEF WHERE OMRADE = 2");

                        idb.update("UPDATE OMRADESCHEF SET AGENT_ID = " + hittaAgentId + " WHERE AGENT_ID = " + agentId);
                    }
                    if(jCombo_Omrade5.getSelectedItem().toString().equals("Norrland")){
                        String agentId = idb.fetchSingle("SELECT AGENT_ID FROM OMRADESCHEF WHERE OMRADE = 4");

                        idb.update("UPDATE OMRADESCHEF SET AGENT_ID = " + hittaAgentId + " WHERE AGENT_ID = " + agentId);
                    }
                    if(jCombo_Omrade5.getSelectedItem().toString().equals("Svealand")){
                        String agentId = idb.fetchSingle("SELECT AGENT_ID FROM OMRADESCHEF WHERE OMRADE = 1");

                        idb.update("UPDATE OMRADESCHEF SET AGENT_ID = " + hittaAgentId + " WHERE AGENT_ID = " + agentId);

                    }
                    JOptionPane.showMessageDialog(null, "Chefen över detta område har nu ändrats");
                }
                else{
                    JOptionPane.showMessageDialog(null, "En agent med det angivna namnet finns ej i systemet");
                }
            }
            catch (InfException ex) {
                JOptionPane.showMessageDialog(null, "Angiven agent är Områdeschef och kan därav inte vara chef över ytterliggare ett annat område");
            }
        }
    }//GEN-LAST:event_jAndraOmradesChefActionPerformed

    // Ändrar kontorschef
    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        String namnPaAgent = jNamnPaAgent2.getText();
        String namnPaKontor = "'" + jCombo_Kontor.getSelectedItem().toString() + "'";

        if (Validation.textFieldHasValue(jNamnPaAgent2)){
            try {
                String hittaKontorsNamn = idb.fetchSingle("SELECT AGENT_ID FROM KONTORSCHEF WHERE KONTORSBETECKNING = " + namnPaKontor);
                String hittaAgentId = idb.fetchSingle("SELECT AGENT_ID FROM AGENT WHERE NAMN = '" + namnPaAgent + "'");
                String fraga = "INSERT INTO KONTORSCHEF (AGENT_ID, KONTORSBETECKNING) VALUES (" + hittaAgentId + ", " + namnPaKontor + ")";
                System.out.println(fraga);

                if(hittaAgentId != null){

                    idb.delete("DELETE FROM KONTORSCHEF WHERE AGENT_ID = " + hittaKontorsNamn);
                    idb.insert(fraga);
                    JOptionPane.showMessageDialog(null, "Kontorschefen har nu ändrats");
                }
                else{
                    JOptionPane.showMessageDialog(null, "En agent med det angivna namnet hittas ej");
                }
            } catch (InfException ex) {
            }
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jCombo_ValjAlien3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCombo_ValjAlien3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCombo_ValjAlien3ActionPerformed

    // Med denna metod tillåts användaren ta bort en alien ur systemet, alien ID tas bort från alla tabeller där alien ID förekommer
    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        String alienNamn = jCombo_ValjAlien3.getSelectedItem().toString();
        String fraga = "DELETE FROM ALIEN WHERE NAMN = '" + alienNamn + "'";
        String id = "";
        try{ id = idb.fetchSingle("SELECT alien_ID from alien where namn = '" + alienNamn + "'");}
        catch (Exception e) {
            }
        
        try {
            idb.delete(fraga);
            JOptionPane.showMessageDialog(null, "Denna alien har nu blivit borttagen");
        } catch (InfException ex) {
            JOptionPane.showMessageDialog(null, ex);
        }
        
        try{
                idb.delete("DELETE FROM worm WHERE ALIEN_ID = " + id);}
        catch (Exception e) {
            }
        try{
                idb.delete("DELETE FROM boglodite WHERE ALIEN_ID = " + id);}
                 catch (Exception e) {
            }
        try{
                idb.delete("DELETE FROM squid WHERE ALIEN_ID = " + id);}
                catch (Exception e) {}
        tömComboBoxValjAlien();
        fyllComboBoxValjAlien();
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jCombo_ValjAgent2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCombo_ValjAgent2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCombo_ValjAgent2ActionPerformed

    // Med denna metod tillåts användaren ta bort en agent ur systemet, agent ID tas bort från alla tabeller där agent ID förekommer
    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        String agentNamn = jCombo_ValjAgent2.getSelectedItem().toString();
        String agentId = "SELECT AGENT_ID FROM AGENT WHERE NAMN = '" + agentNamn + "'";
        String agentensID = "";
        String fårinte = "system";
        try {
                    agentensID = idb.fetchSingle(agentId);}
                    catch(Exception ex) {JOptionPane.showMessageDialog(null, "felkod 1");}
        if(agentNamn.equalsIgnoreCase(fårinte)){JOptionPane.showMessageDialog(null, "Du får inte ta bort system"); }
        else{
        try {
            if(agentNamn != null){
                
                String taBortAlien = "UPDATE ALIEN SET ANSVARIG_AGENT = 0 WHERE ANSVARIG_AGENT = " + agentensID;
                String taBortFaltAgent = "DELETE from faltagent where Agent_ID = "+ agentensID;
                String taBortInnehar_Fordon = "UPDATE innehar_fordon SET Agent_ID = 0 WHERE AGENT_ID = " + agentensID;
                String taBortInnehar_Utrustning = "UPDATE innehar_utrustning SET Agent_ID = 0 WHERE AGENT_ID = " + agentensID;
                String taBortkontorsChef = "UPDATE kontorschef SET Agent_ID = 0 WHERE AGENT_ID = " + agentensID;
                String taBortOmradeChef = "DELETE from omradeschef where Agent_ID = " + agentensID;
                String fraga = "DELETE FROM AGENT WHERE agent_ID = "+agentensID;
                System.out.print(agentId);
                
                    
                     try {
                    idb.update(taBortAlien);}
                     catch(InfException ex) {}
                     try {
                    idb.delete(taBortFaltAgent);}
                     catch(InfException ex) {}
                     try {
                    idb.update(taBortInnehar_Fordon);}
                     catch(InfException ex) {}
                     try {
                    idb.update(taBortInnehar_Utrustning);}
                     catch(InfException ex) {}
                     try {
                    idb.update(taBortkontorsChef);}
                     catch(InfException ex) {}
                     try {
                    idb.delete(taBortOmradeChef);}
                     catch(InfException ex) {}
                     try {
                    idb.delete(fraga);
                    JOptionPane.showMessageDialog(null, "Denna agent har nu tagits bort från systemet");}
                     catch(InfException ex) {
                     
                     JOptionPane.showMessageDialog(null, "Koden funkar inte");}
                
               
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Det angivna namnet på agenten stämmer ej");
        }
        tömComboBoxAgent();
        fyllComboBoxAgent();
        }
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jTxt_listaDatum2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTxt_listaDatum2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTxt_listaDatum2ActionPerformed

    private String getRasen(String id) {
        String rättRas = "";
        String squid = ("select alien_id from squid where alien_id =" + id);
        String wormId = ("select alien_id from worm where alien_id =" + id);
        String bogloditeId = ("select alien_id from boglodite where alien_id =" + id);
         try {
            squid = idb.fetchSingle(squid);
            if (squid.equals(id)) {
                rättRas = "Squid";
            }
       }
            catch (Exception e) {} 
       try {
            wormId = idb.fetchSingle(wormId);
            if (wormId.equals(id)) {
                rättRas = "Worm";
            }
        } catch (Exception e) {}     
        
       try {
            bogloditeId = idb.fetchSingle(bogloditeId);
            if (bogloditeId.equals(id)) {
                rättRas = "Boglodite";
            }
        } catch (Exception e) {}
       return rättRas;
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jAndraOmradesChef;
    private javax.swing.JButton jBtnPasswordChange;
    private javax.swing.JButton jBtn_BekraftaSok;
    private javax.swing.JButton jBtn_BekraftaSok1;
    private javax.swing.JButton jBtn_BekraftaSok2;
    private javax.swing.JButton jBtn_Registrera1;
    private javax.swing.JButton jBtn_Registrera2;
    private javax.swing.JButton jBtn_Registrera4;
    private javax.swing.JButton jBtn_Registrera5;
    private javax.swing.JButton jBtn_Registrera8;
    private javax.swing.JButton jBtn_RegistreraUtrustning1;
    private javax.swing.JButton jBtn_RegistreraUtrustning2;
    private javax.swing.JButton jBtn_Utrustningen;
    private javax.swing.JButton jBtn_listaBoglodite;
    private javax.swing.JButton jBtn_listaSquid;
    private javax.swing.JButton jBtn_listaWorm;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JCheckBox jCheckBox1;
    private javax.swing.JCheckBox jCheckBox10;
    private javax.swing.JCheckBox jCheckBox11;
    private javax.swing.JCheckBox jCheckBox12;
    private javax.swing.JCheckBox jCheckBox13;
    private javax.swing.JCheckBox jCheckBox2;
    private javax.swing.JCheckBox jCheckBox3;
    private javax.swing.JCheckBox jCheckBox4;
    private javax.swing.JCheckBox jCheckBox5;
    private javax.swing.JCheckBox jCheckBox6;
    private javax.swing.JCheckBox jCheckBox7;
    private javax.swing.JCheckBox jCheckBox8;
    private javax.swing.JCheckBox jCheckBox9;
    private javax.swing.JComboBox<String> jCombo_AdminStatus;
    private javax.swing.JComboBox<String> jCombo_AdminStatus1;
    private javax.swing.JComboBox<String> jCombo_AnsvarigAgent1;
    private javax.swing.JComboBox<String> jCombo_AnsvarigAgent2;
    private javax.swing.JComboBox<String> jCombo_Kontor;
    private javax.swing.JComboBox<String> jCombo_Omrade1;
    private javax.swing.JComboBox<String> jCombo_Omrade2;
    private javax.swing.JComboBox<String> jCombo_Omrade3;
    private javax.swing.JComboBox<String> jCombo_Omrade4;
    private javax.swing.JComboBox<String> jCombo_Omrade5;
    private javax.swing.JComboBox<String> jCombo_Plats;
    private javax.swing.JComboBox<String> jCombo_Plats1;
    private javax.swing.JComboBox<String> jCombo_Plats2;
    private javax.swing.JComboBox<String> jCombo_Ras1;
    private javax.swing.JComboBox<String> jCombo_Ras2;
    private javax.swing.JComboBox<String> jCombo_Utrustning1;
    private javax.swing.JComboBox<String> jCombo_UtrustningTyp;
    private javax.swing.JComboBox<String> jCombo_ValjAgent;
    private javax.swing.JComboBox<String> jCombo_ValjAgent2;
    private javax.swing.JComboBox<String> jCombo_ValjAlien;
    private javax.swing.JComboBox<String> jCombo_ValjAlien2;
    private javax.swing.JComboBox<String> jCombo_ValjAlien3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel jLabelAgentNamn;
    private javax.swing.JLabel jLabel_menuItem1;
    private javax.swing.JLabel jLabel_menuItem2;
    private javax.swing.JLabel jLabel_menuItem3;
    private javax.swing.JLabel jLabel_menuItem4;
    private javax.swing.JLabel jLabel_menuItem5;
    private javax.swing.JLabel jLabel_menuItem6;
    private javax.swing.JLabel jLblDisplayPassword;
    private javax.swing.JLabel jLbl_BenamningUtrustning1;
    private javax.swing.JLabel jLbl_BenamningUtrustning2;
    private javax.swing.JLabel jLbl_BenamningUtrustning3;
    private javax.swing.JLabel jLbl_ListaMellanDatum;
    private javax.swing.JLabel jLbl_ListaMellanDatum1;
    private javax.swing.JLabel jLbl_MsgReg1;
    private javax.swing.JLabel jLbl_MsgReg2;
    private javax.swing.JLabel jLbl_MsgReg3;
    private javax.swing.JLabel jLbl_MsgReg4;
    private javax.swing.JLabel jLbl_MsgReg5;
    private javax.swing.JLabel jLbl_RegConfirm;
    private javax.swing.JLabel jLbl_RegConfirm1;
    private javax.swing.JLabel jLbl_typFraga;
    private javax.swing.JLabel jLbl_welcome;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenu jMenu4;
    private javax.swing.JMenuBar jMenuBar2;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JTextField jNamnPaAgent;
    private javax.swing.JTextField jNamnPaAgent2;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JPanel jPanel_AdminMeny;
    private javax.swing.JPanel jPanel_Agent;
    private javax.swing.JPanel jPanel_Utrustning;
    private javax.swing.JPanel jPanel_container;
    private javax.swing.JPanel jPanel_dashboard;
    private javax.swing.JPanel jPanel_lista;
    private javax.swing.JPanel jPanel_logoANDname;
    private javax.swing.JPanel jPanel_menu;
    private javax.swing.JPanel jPanel_users;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField jTxtNewPassword;
    private javax.swing.JTextField jTxtTypFragaSvar;
    private javax.swing.JTextField jTxt_Datum;
    private javax.swing.JTextField jTxt_Datum1;
    private javax.swing.JTextField jTxt_Losenord;
    private javax.swing.JTextField jTxt_Losenord1;
    private javax.swing.JTextField jTxt_Namn;
    private javax.swing.JTextField jTxt_Namn1;
    private javax.swing.JTextField jTxt_NyttDatum;
    private javax.swing.JTextField jTxt_NyttDatum1;
    private javax.swing.JTextField jTxt_NyttLosenord;
    private javax.swing.JTextField jTxt_NyttLosenord1;
    private javax.swing.JTextField jTxt_NyttNamn;
    private javax.swing.JTextField jTxt_NyttNamn1;
    private javax.swing.JTextField jTxt_NyttNr;
    private javax.swing.JTextField jTxt_NyttNr1;
    private javax.swing.JTextField jTxt_RasFraga2;
    private javax.swing.JTextField jTxt_Rasfraga;
    private javax.swing.JTextArea jTxt_TOP3;
    private javax.swing.JTextField jTxt_Telefon;
    private javax.swing.JTextField jTxt_Telefon1;
    private javax.swing.JTextField jTxt_benamning;
    private javax.swing.JTextField jTxt_listaDatum1;
    private javax.swing.JTextField jTxt_listaDatum2;
    private javax.swing.JTextArea jTxt_listaSvarRuta;
    // End of variables declaration//GEN-END:variables
}
